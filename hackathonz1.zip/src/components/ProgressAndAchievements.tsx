/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import * as Icons from 'lucide-react';
import { DEFAULT_BADGES, MOCK_LEADERBOARD } from '../mockData';
import { AchievementBadge } from '../types';

interface AchievementsProps {
  xp: number;
  streak: number;
}

export const AchievementsPage: React.FC<AchievementsProps> = ({ xp, streak }) => {
  return (
    <div className="space-y-6 p-4 md:p-6 max-w-7xl mx-auto">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-black text-[#0F3D91]">Academic Honors & Badges</h1>
        <p className="text-sm text-slate-500">Track unlocked credentials, badges, and real-time class ranking.</p>
      </div>

      {/* Overview Bento Board */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Metric 1 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Experience</span>
            <Icons.Award className="h-5 w-5 text-[#2F5BEA]" />
          </div>
          <p className="text-3xl font-black text-[#0F3D91] mt-2">{xp} XP</p>
          <div className="mt-3 flex items-center gap-1 text-xs text-green-600 font-bold">
            <Icons.ChevronRight className="h-3 w-3" />
            <span>+150 XP today from Agents</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Learning Level</span>
            <Icons.GraduationCap className="h-5 w-5 text-amber-500" />
          </div>
          <p className="text-3xl font-black text-[#0F3D91] mt-2">Lvl 4 (Academic)</p>
          <div className="mt-3 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div className="bg-amber-500 h-full rounded-full" style={{ width: '65%' }}></div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Consistency Streak</span>
            <Icons.Flame className="h-5 w-5 text-orange-500 fill-orange-500" />
          </div>
          <p className="text-3xl font-black text-[#0F3D91] mt-2">{streak} Days</p>
          <div className="mt-3 text-xs text-slate-500">
            Next milestone: <span className="font-bold text-orange-600">10-Day Streak badge</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Leaderboard Rank</span>
            <Icons.Activity className="h-5 w-5 text-green-500" />
          </div>
          <p className="text-3xl font-black text-[#0F3D91] mt-2">#3 in Class</p>
          <div className="mt-3 text-xs text-slate-500 font-medium">
            Top 5% of all active university profiles
          </div>
        </div>
      </div>

      {/* Badges Section & Leaderboard */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Unlocked Badges Grid */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-extrabold text-[#0F3D91] flex items-center gap-2">
            <Icons.Cpu className="h-5 w-5 text-[#2F5BEA]" />
            Your AI Platform Badges
          </h2>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {DEFAULT_BADGES.map((badge) => {
              const IconComponent = (Icons as any)[badge.icon];
              const isLocked = !badge.unlockedAt && badge.progress === undefined;
              const hasProgress = badge.progress !== undefined && badge.maxProgress !== undefined;

              return (
                <div key={badge.id} className={`rounded-2xl border p-4 flex items-start gap-3 bg-white transition-all ${
                  isLocked ? 'border-dashed border-slate-200 opacity-60' : 'border-slate-200 hover:border-slate-300'
                }`}>
                  <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${
                    isLocked ? 'bg-slate-100 text-slate-400' : 'bg-[#EAF2FF] text-[#0F3D91]'
                  }`}>
                    {IconComponent && <IconComponent className="h-5 w-5" />}
                  </div>

                  <div className="space-y-1 w-full">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-extrabold text-[#0F3D91]">{badge.title}</h4>
                      <span className="text-[10px] font-bold text-[#2F5BEA] bg-[#EAF2FF] px-2 py-0.5 rounded-sm">
                        +{badge.xpValue} XP
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 leading-snug">{badge.description}</p>
                    
                    {badge.unlockedAt && (
                      <span className="text-[10px] text-green-600 font-bold block pt-1 flex items-center gap-1">
                        <Icons.Check className="h-3 w-3" />
                        Unlocked {badge.unlockedAt}
                      </span>
                    )}

                    {hasProgress && (
                      <div className="pt-2 w-full">
                        <div className="flex justify-between text-[10px] text-slate-400 font-medium mb-1">
                          <span>Progress</span>
                          <span>{badge.progress}/{badge.maxProgress}</span>
                        </div>
                        <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div className="bg-[#2F5BEA] h-full rounded-full" style={{ width: `${(badge.progress! / badge.maxProgress!) * 100}%` }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Leaderboard Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <h2 className="text-lg font-extrabold text-[#0F3D91] flex items-center gap-2">
            <Icons.Activity className="h-5 w-5 text-[#2F5BEA]" />
            Active Leaderboard
          </h2>

          <div className="divide-y divide-slate-100">
            {MOCK_LEADERBOARD.map((user) => (
              <div key={user.rank} className={`flex items-center justify-between py-3 ${
                user.active ? 'bg-[#EAF2FF] rounded-xl px-2.5 my-1 border border-blue-100' : ''
              }`}>
                <div className="flex items-center gap-3">
                  <span className={`h-6 w-6 rounded-full flex items-center justify-center font-bold text-xs ${
                    user.rank === 1 ? 'bg-amber-100 text-amber-800' :
                    user.rank === 2 ? 'bg-slate-100 text-slate-800' : 'text-slate-500'
                  }`}>
                    {user.rank}
                  </span>
                  <div>
                    <p className={`text-sm font-bold ${user.active ? 'text-[#0F3D91]' : 'text-slate-700'}`}>
                      {user.name}
                    </p>
                    <p className="text-[10px] text-slate-400 font-semibold">{user.level}</p>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-black text-[#0F3D91]">{user.xp}</span>
                  <span className="text-[10px] text-slate-400 font-medium block">XP</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export const ProgressPage: React.FC = () => {
  return (
    <div className="space-y-6 p-4 md:p-6 max-w-7xl mx-auto">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-black text-[#0F3D91]">Progress & Skill Analytics</h1>
        <p className="text-sm text-slate-500">Real-time statistics driven by agent completed metrics and quiz answers.</p>
      </div>

      {/* Grid of Custom SVG Charts */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        {/* SVG Line Graph: Weekly study minutes */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div>
            <h3 className="text-sm font-extrabold text-[#0F3D91]">Weekly Study Time (Minutes)</h3>
            <p className="text-xs text-slate-400">Minutes spent in agents discussions.</p>
          </div>

          <div className="h-48 w-full flex items-end justify-center py-2">
            <svg viewBox="0 0 300 120" className="w-full h-full overflow-visible">
              {/* Grid lines */}
              <line x1="20" y1="20" x2="280" y2="20" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="20" y1="50" x2="280" y2="50" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="20" y1="80" x2="280" y2="80" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="20" y1="100" x2="280" y2="100" stroke="#e2e8f0" strokeWidth="1" />

              {/* Data curve line */}
              <polyline
                fill="none"
                stroke="#2F5BEA"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                points="30,100 70,80 110,95 150,55 190,40 230,25 270,15"
              />

              {/* Gradient fill */}
              <path
                d="M30,100 L70,80 L110,95 L150,55 L190,40 L230,25 L270,15 L270,100 L30,100 Z"
                fill="url(#grad)"
                opacity="0.1"
              />

              <defs>
                <linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#2F5BEA" />
                  <stop offset="100%" stopColor="#ffffff" />
                </linearGradient>
              </defs>

              {/* Dots */}
              <circle cx="30" cy="100" r="4" fill="#0F3D91" />
              <circle cx="150" cy="55" r="4" fill="#0F3D91" />
              <circle cx="270" cy="15" r="5" fill="#2F5BEA" stroke="#ffffff" strokeWidth="1.5" />

              {/* Day Labels */}
              <text x="30" y="115" fontSize="8" fontWeight="bold" fill="#94a3b8" textAnchor="middle">Mon</text>
              <text x="110" y="115" fontSize="8" fontWeight="bold" fill="#94a3b8" textAnchor="middle">Wed</text>
              <text x="190" y="115" fontSize="8" fontWeight="bold" fill="#94a3b8" textAnchor="middle">Fri</text>
              <text x="270" y="115" fontSize="8" fontWeight="bold" fill="#94a3b8" textAnchor="middle">Today</text>
            </svg>
          </div>
        </div>

        {/* SVG Bar Chart: Syllabus mastery per unit */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div>
            <h3 className="text-sm font-extrabold text-[#0F3D91]">Syllabus Mastery (%)</h3>
            <p className="text-xs text-slate-400">Progression across educational units.</p>
          </div>

          <div className="h-48 w-full flex items-end justify-center py-2">
            <svg viewBox="0 0 300 120" className="w-full h-full overflow-visible">
              <line x1="20" y1="100" x2="280" y2="100" stroke="#e2e8f0" strokeWidth="1" />

              {/* Bar 1 */}
              <rect x="40" y="30" width="22" height="70" rx="3" fill="#0F3D91" />
              {/* Bar 2 */}
              <rect x="100" y="45" width="22" height="55" rx="3" fill="#2F5BEA" />
              {/* Bar 3 */}
              <rect x="160" y="15" width="22" height="85" rx="3" fill="#38BDF8" />
              {/* Bar 4 */}
              <rect x="220" y="60" width="22" height="40" rx="3" fill="#94a3b8" />

              {/* Values */}
              <text x="51" y="24" fontSize="8" fontWeight="bold" fill="#0F3D91" textAnchor="middle">70%</text>
              <text x="111" y="39" fontSize="8" fontWeight="bold" fill="#2F5BEA" textAnchor="middle">55%</text>
              <text x="171" y="9" fontSize="8" fontWeight="bold" fill="#0284c7" textAnchor="middle">85%</text>
              <text x="231" y="54" fontSize="8" fontWeight="bold" fill="#64748b" textAnchor="middle">40%</text>

              {/* Labels */}
              <text x="51" y="112" fontSize="8" fontWeight="bold" fill="#64748b" textAnchor="middle">OS Theory</text>
              <text x="111" y="112" fontSize="8" fontWeight="bold" fill="#64748b" textAnchor="middle">Maths</text>
              <text x="171" y="112" fontSize="8" fontWeight="bold" fill="#64748b" textAnchor="middle">Computing</text>
              <text x="231" y="112" fontSize="8" fontWeight="bold" fill="#64748b" textAnchor="middle">Physics</text>
            </svg>
          </div>
        </div>

        {/* SVG Donut Chart: Quiz Accuracy */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div>
            <h3 className="text-sm font-extrabold text-[#0F3D91]">Quiz Accuracy</h3>
            <p className="text-xs text-slate-400">Performance ratio over last 50 questions.</p>
          </div>

          <div className="h-48 w-full flex items-center justify-center py-2">
            <svg viewBox="0 0 120 120" className="h-32 w-32 overflow-visible">
              {/* Gray circle */}
              <circle cx="60" cy="60" r="45" fill="none" stroke="#f1f5f9" strokeWidth="12" />
              
              {/* Blue circle overlay (80% stroke dasharray) */}
              <circle
                cx="60"
                cy="60"
                r="45"
                fill="none"
                stroke="#2F5BEA"
                strokeWidth="12"
                strokeDasharray={`${2 * Math.PI * 45 * 0.8} ${2 * Math.PI * 45 * 0.2}`}
                strokeDashoffset={`${2 * Math.PI * 45 * 0.25}`}
                strokeLinecap="round"
              />

              {/* Inner details text */}
              <text x="60" y="58" fontSize="16" fontWeight="900" fill="#0F3D91" textAnchor="middle">80%</text>
              <text x="60" y="72" fontSize="8" fontWeight="bold" fill="#94a3b8" textAnchor="middle">Correct</text>
            </svg>
          </div>
        </div>
      </div>

      {/* Weak & Strong areas */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3.5">
          <h3 className="text-base font-extrabold text-green-700 flex items-center gap-2">
            <Icons.CheckCircle className="h-5 w-5" />
            Identified Academic Strengths
          </h3>
          <ul className="space-y-2.5">
            <li className="flex items-center gap-2.5 rounded-lg bg-green-50 px-3 py-2 text-xs font-semibold text-green-800">
              <span className="h-1.5 w-1.5 rounded-full bg-green-600"></span>
              Gantt Chart calculations for preemption scheduling (Avg 95% accuracy)
            </li>
            <li className="flex items-center gap-2.5 rounded-lg bg-green-50 px-3 py-2 text-xs font-semibold text-green-800">
              <span className="h-1.5 w-1.5 rounded-full bg-green-600"></span>
              Quantum gate probability calculations (Hadamard superposition metrics)
            </li>
          </ul>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3.5">
          <h3 className="text-base font-extrabold text-red-600 flex items-center gap-2">
            <Icons.ShieldAlert className="h-5 w-5" />
            Identified Focus Areas (Weaknesses)
          </h3>
          <ul className="space-y-2.5">
            <li className="flex items-center gap-2.5 rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-800">
              <span className="h-1.5 w-1.5 rounded-full bg-red-600"></span>
              Multilevel queue starvation prevention mechanisms (Quiz Day 5)
            </li>
            <li className="flex items-center gap-2.5 rounded-lg bg-red-50 px-3 py-2 text-xs font-semibold text-red-800">
              <span className="h-1.5 w-1.5 rounded-full bg-red-600"></span>
              Cryogenic qubit decoherence factors and state noise control
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
