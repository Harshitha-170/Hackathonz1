/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import * as Icons from 'lucide-react';
import { AIAgent, AgentStatus, LearningResource, MindMapNode, MindMapLink, FlowchartStep, QuizQuestion } from '../types';
import { generateCustomLearning, generateExamAnswer } from '../mockData';

interface WorkspaceProps {
  topic: string;
  learningResource: LearningResource;
  mindMapNodes: MindMapNode[];
  mindMapLinks: MindMapLink[];
  flowchartSteps: FlowchartStep[];
  quizQuestions: QuizQuestion[];
  isGenerating: boolean;
  onTopicSearch: (newTopic: string) => void;
  xp: number;
  setXp: React.Dispatch<React.SetStateAction<number>>;
  streak: number;
  setStreak: React.Dispatch<React.SetStateAction<number>>;
}

type ToolTab = 'text' | 'mindmap' | 'flowchart' | 'visual' | 'video' | 'quiz' | 'answer-gen' | 'flashcards';

export const WorkspacePage: React.FC<WorkspaceProps> = ({
  topic,
  learningResource,
  mindMapNodes,
  mindMapLinks,
  flowchartSteps,
  quizQuestions,
  isGenerating,
  onTopicSearch,
  xp,
  setXp,
  streak,
  setStreak
}) => {
  // Main tool navigation
  const [activeTool, setActiveTool] = useState<ToolTab>('text');

  // Agent orchestration states
  const [agents, setAgents] = useState<AIAgent[]>([
    { id: '1', name: 'Learning Planner', role: 'Curriculum architect', icon: 'BookOpen', status: 'completed', progress: 100, outputLog: [] },
    { id: '2', name: 'Topic Analyzer', role: 'Syllabus parser', icon: 'Search', status: 'completed', progress: 100, outputLog: [] },
    { id: '3', name: 'Research Agent', role: 'Web & document crawler', icon: 'Layers', status: 'completed', progress: 100, outputLog: [] },
    { id: '4', name: 'Mind Map Generator', role: 'Semantic linker', icon: 'Cpu', status: 'completed', progress: 100, outputLog: [] },
    { id: '5', name: 'Flowchart Agent', role: 'Procedural compiler', icon: 'Activity', status: 'completed', progress: 100, outputLog: [] },
    { id: '6', name: 'Visual Explainer', role: 'Graphics & Layout design', icon: 'Sparkles', status: 'completed', progress: 100, outputLog: [] },
    { id: '7', name: 'Quiz Generator', role: 'Assessment formulation', icon: 'HelpCircle', status: 'completed', progress: 100, outputLog: [] }
  ]);

  const [agentLogs, setAgentLogs] = useState<string[]>([
    'System: Booting orchestration framework...',
    'Orchestrator: Input objective validated.',
    'System: Coordinating specialized AI agents...',
    'Planner Agent: Structured 7-day academic roadmap successfully compiled.',
    'Analyzer Agent: Extracted key syllabus dimensions.',
    'Research Agent: Retrieved peer literature examples.',
    'System: Collaborative educational resource ready.'
  ]);

  // Video State
  const [isPlaying, setIsPlaying] = useState(false);
  const [videoProgress, setVideoProgress] = useState(30);

  // Exam Answer State
  const [selectedMarks, setSelectedMarks] = useState<number>(10);
  const [examAnswer, setExamAnswer] = useState(() => generateExamAnswer(topic, 10));

  useEffect(() => {
    setExamAnswer(generateExamAnswer(topic, selectedMarks));
  }, [topic, selectedMarks]);

  // Flashcards state
  const [activeFlashcard, setActiveFlashcard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const flashcards = [
    { front: 'What is preemptive scheduling?', back: 'A policy where the OS kernel can interrupt a running process to allocate CPU time to a higher priority task.' },
    { front: 'What does Turnaround Time represent?', back: 'The total duration of time from process submission/arrival to its final completed termination.' },
    { front: 'Name one disadvantage of FCFS (First Come First Served).', back: 'The Convoy Effect: where short processes wait a long time for a single long process to finish.' },
    { front: 'Explain superposition in Quantum Computing.', back: 'The physical state allowing qubits to represent complex combinations of 0 and 1 simultaneously.' }
  ];

  // Quiz assessment state
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [showCertificate, setShowCertificate] = useState(false);

  // Simulated live orchestration runner when starting search
  useEffect(() => {
    if (isGenerating) {
      setAgentLogs(['System: Received custom request: "' + topic + '"', 'System: Instantiating orchestration protocol...']);
      
      // Mark all agents thinking
      setAgents(prev => prev.map(a => ({ ...a, status: 'thinking', progress: 20 })));

      // Step-by-step trigger sequence
      let currentIdx = 0;
      const interval = setInterval(() => {
        if (currentIdx < agents.length) {
          const targetAgent = agents[currentIdx];
          
          setAgents(prev => prev.map((a, i) => {
            if (i === currentIdx) {
              return { ...a, status: 'running', progress: 60 };
            }
            if (i < currentIdx) {
              return { ...a, status: 'completed', progress: 100 };
            }
            return { ...a, status: 'thinking' };
          }));

          setAgentLogs(prev => [
            ...prev,
            `[Agent ${currentIdx + 1}] ${targetAgent.name}: Orchestrated execution started...`,
            `[Agent ${currentIdx + 1}] ${targetAgent.name}: Processing variables for "${topic}"`
          ]);

          currentIdx++;
        } else {
          setAgents(prev => prev.map(a => ({ ...a, status: 'completed', progress: 100 })));
          setAgentLogs(prev => [...prev, 'System: Orchestration concluded successfully.', 'System: Generated learning suite in Workspace.']);
          clearInterval(interval);
        }
      }, 900);

      return () => clearInterval(interval);
    }
  }, [isGenerating, topic]);

  // Handle quiz submit
  const handleQuizSubmit = () => {
    let score = 0;
    quizQuestions.forEach((q) => {
      if (answers[q.id]?.toLowerCase() === q.correctAnswer.toLowerCase()) {
        score++;
      }
    });
    setQuizScore(score);
    setQuizSubmitted(true);
    setXp(prev => prev + (score * 50));
    setStreak(prev => prev + 1);
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] w-full overflow-hidden bg-slate-50">
      
      {/* 1. Left Section: Topic History */}
      <div className="hidden w-64 border-r border-slate-200 bg-white p-4 lg:flex flex-col">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Topic History</h3>
        <div className="flex-1 space-y-1.5 overflow-y-auto">
          {['Operating Systems Scheduling Algorithms', 'Quantum Computing Qubits', 'Photosynthesis in Plants', 'Blockchain Consensus Standards'].map((hist, index) => (
            <button
              key={index}
              onClick={() => onTopicSearch(hist)}
              className={`flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-left transition-all cursor-pointer ${
                hist.toLowerCase() === topic.toLowerCase()
                  ? 'bg-blue-50 text-[#0F3D91] border border-blue-100'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Icons.FileText className="h-4 w-4 text-[#2F5BEA] shrink-0" />
              <span className="truncate">{hist}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Center & Right Content Flow */}
      <div className="flex flex-1 flex-col overflow-hidden lg:flex-row">
        
        {/* CENTER MAIN WRAPPER */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Header banner */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#2F5BEA]">
              Current Learning Objective
            </span>
            <h1 className="text-xl font-black text-[#0F3D91] mt-1">{topic}</h1>
            <p className="text-xs text-slate-400 mt-0.5">Custom compiled educational assets generated dynamically.</p>
          </div>

          {/* Core Learning Tools Tab Row */}
          <div className="flex flex-wrap gap-1.5 border-b border-slate-200 pb-2 overflow-x-auto">
            {([
              { id: 'text', label: 'Curriculum Summary', icon: 'FileText' },
              { id: 'mindmap', label: 'Interactive Mind Map', icon: 'Cpu' },
              { id: 'flowchart', label: 'Procedural Flowchart', icon: 'Activity' },
              { id: 'visual', label: 'Visual Explanation', icon: 'Sparkles' },
              { id: 'video', label: 'AI Video Lecture', icon: 'Play' },
              { id: 'quiz', label: 'Practice Quiz', icon: 'HelpCircle' },
              { id: 'answer-gen', label: 'Exam Answer Generator', icon: 'Award' },
              { id: 'flashcards', label: 'Concept Flashcards', icon: 'Layers' }
            ] as const).map((tab) => {
              const TabIcon = (Icons as any)[tab.icon];
              const isActive = activeTool === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTool(tab.id)}
                  className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#0F3D91] text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:border-[#2F5BEA] hover:bg-[#EAF2FF]'
                  }`}
                >
                  {TabIcon && <TabIcon className="h-3.5 w-3.5" />}
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* ACTIVE TOOL CANVAS VIEWPORT */}
          <div className="min-h-[400px]">
            {/* TEXT CURRICULUM TAB */}
            {activeTool === 'text' && (
              <div className="space-y-6">
                <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3.5 shadow-xs">
                  <h3 className="text-base font-extrabold text-[#0F3D91]">Executive Summary</h3>
                  <p className="text-sm text-slate-600 leading-relaxed">{learningResource.summary}</p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                    <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Key Syllabus Concepts</h3>
                    <div className="space-y-3">
                      {learningResource.keyConcepts.map((c, i) => (
                        <div key={i} className="rounded-xl bg-slate-50 p-3.5 border border-slate-100">
                          <h4 className="text-xs font-extrabold text-[#0F3D91]">{c.title}</h4>
                          <p className="text-xs text-slate-500 mt-1 leading-normal">{c.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                    <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Critical Dictionary Terms</h3>
                    <div className="space-y-3">
                      {learningResource.definitions.map((d, i) => (
                        <div key={i} className="flex gap-2 text-xs">
                          <span className="font-bold text-[#2F5BEA] min-w-24 border-r border-slate-100 pr-2">{d.term}</span>
                          <span className="text-slate-500 pl-1 leading-snug">{d.meaning}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Examples */}
                {learningResource.examples.map((ex, i) => (
                  <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                    <div className="flex items-center gap-2 text-emerald-700">
                      <Icons.CheckCircle className="h-5 w-5" />
                      <h3 className="text-base font-extrabold">Step-by-Step Practical Scenario: {ex.title}</h3>
                    </div>
                    <p className="text-sm text-slate-600">{ex.scenario}</p>
                    <div className="space-y-2 border-l-2 border-emerald-100 pl-4">
                      {ex.steps.map((st, sIdx) => (
                        <p key={sIdx} className="text-xs text-slate-500">
                          <span className="font-bold text-[#0F3D91]">Step {sIdx+1}:</span> {st}
                        </p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* MIND MAP TAB */}
            {activeTool === 'mindmap' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-extrabold text-[#0F3D91]">Dynamic Concept Mind Map</h3>
                    <p className="text-xs text-slate-400">Interactive zoomable node linkages compiled by the Semantic Linker agent.</p>
                  </div>
                  <div className="flex gap-1.5">
                    <button className="p-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg cursor-pointer">
                      <Icons.Maximize2 className="h-3.5 w-3.5 text-slate-500" />
                    </button>
                  </div>
                </div>

                {/* SVG Concept Map Stage */}
                <div className="relative border border-slate-100 bg-slate-50 rounded-2xl h-80 w-full overflow-hidden flex items-center justify-center">
                  <svg className="w-full h-full" viewBox="0 0 500 300">
                    {/* Node Link Connections */}
                    <line x1="250" y1="150" x2="100" y2="70" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="3 3" />
                    <line x1="250" y1="150" x2="400" y2="70" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="3 3" />
                    <line x1="250" y1="150" x2="100" y2="230" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="3 3" />
                    <line x1="250" y1="150" x2="400" y2="230" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="3 3" />

                    <line x1="100" y1="70" x2="30" y2="30" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="100" y1="70" x2="150" y2="20" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="100" y1="70" x2="30" y2="110" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="400" y1="70" x2="450" y2="30" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="100" y1="230" x2="50" y2="270" stroke="#cbd5e1" strokeWidth="1.5" />
                    <line x1="400" y1="230" x2="450" y2="270" stroke="#cbd5e1" strokeWidth="1.5" />

                    {/* Nodes mapping */}
                    {mindMapNodes.map((node) => (
                      <g key={node.id} className="cursor-pointer group">
                        <circle
                          cx={node.x}
                          cy={node.y}
                          r={node.type === 'root' ? '24' : node.type === 'category' ? '18' : '10'}
                          fill={node.color}
                          className="transition-transform group-hover:scale-105"
                          stroke={node.type === 'detail' ? '#94a3b8' : 'none'}
                        />
                        <text
                          x={node.x}
                          y={node.y + (node.type === 'root' ? 35 : node.type === 'category' ? 28 : 20)}
                          fontSize={node.type === 'root' ? '10' : '8'}
                          fontWeight="bold"
                          fill="#0F3D91"
                          textAnchor="middle"
                          className="pointer-events-none"
                        >
                          {node.label}
                        </text>
                      </g>
                    ))}
                  </svg>
                </div>
              </div>
            )}

            {/* FLOWCHART TAB */}
            {activeTool === 'flowchart' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div>
                  <h3 className="text-base font-extrabold text-[#0F3D91]">Procedural Lifecycle Flowchart</h3>
                  <p className="text-xs text-slate-400">Step-by-step procedural workflow designed by the Flowchart Compiler agent.</p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {flowchartSteps.map((step, idx) => (
                    <div key={step.id} className="relative rounded-xl border border-slate-100 bg-slate-50 p-4 hover:border-[#2F5BEA] transition-all">
                      <div className="flex items-center gap-2">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#EAF2FF] text-[10px] font-black text-[#0F3D91]">
                          {idx + 1}
                        </span>
                        <span className={`rounded-md px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider ${
                          step.type === 'start' ? 'bg-green-100 text-green-800' :
                          step.type === 'decision' ? 'bg-amber-100 text-amber-800' :
                          step.type === 'end' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {step.type}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-[#0F3D91] mt-2">{step.title}</h4>
                      <p className="text-xs text-slate-500 mt-1 leading-snug">{step.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* VISUAL EXPLANATION TAB */}
            {activeTool === 'visual' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div>
                  <h3 className="text-base font-extrabold text-[#0F3D91]">Infographic Explanation Layout</h3>
                  <p className="text-xs text-slate-400">Visual dashboard representing system bottlenecks and parameters.</p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="rounded-2xl bg-[#EAF2FF] p-5 text-[#0F3D91] space-y-3 border border-blue-100">
                    <Icons.Cpu className="h-6 w-6 text-[#2F5BEA]" />
                    <h4 className="text-sm font-extrabold">Active System Processing</h4>
                    <p className="text-xs text-[#0f3d91]/80 leading-relaxed">Task states transition dynamically through memory channels directly into available logic cores.</p>
                  </div>

                  <div className="rounded-2xl bg-slate-50 p-5 text-slate-700 space-y-3 border border-slate-100">
                    <Icons.Activity className="h-6 w-6 text-[#2F5BEA]" />
                    <h4 className="text-sm font-extrabold">Scheduler Dispatch Cycle</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">Interrupt-driven context registers are saved to stack frames, reducing timing jitters.</p>
                  </div>

                  <div className="rounded-2xl bg-[#EAF2FF] p-5 text-[#0F3D91] space-y-3 border border-blue-100">
                    <Icons.Flame className="h-6 w-6 text-orange-500" />
                    <h4 className="text-sm font-extrabold">Avoid Queue Starvation</h4>
                    <p className="text-xs text-[#0f3d91]/80 leading-relaxed">Aging algorithms systematically elevate lower priority task groups into executable pipelines.</p>
                  </div>
                </div>
              </div>
            )}

            {/* VIDEO TAB */}
            {activeTool === 'video' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div>
                  <h3 className="text-base font-extrabold text-[#0F3D91]">AI-Generated Video Presentation</h3>
                  <p className="text-xs text-slate-400">Simulated synthetic micro-lecture detailing the core syllabus dimensions.</p>
                </div>

                <div className="relative overflow-hidden rounded-2xl bg-slate-900 aspect-video w-full max-w-2xl mx-auto flex flex-col justify-between p-4 text-white">
                  {/* Top overlay */}
                  <div className="flex justify-between items-center bg-black/40 p-2.5 rounded-xl backdrop-blur-xs">
                    <span className="text-xs font-semibold">Micro-Lesson: {topic}</span>
                    <span className="text-[10px] bg-red-600 px-1.5 py-0.5 rounded-sm font-bold uppercase tracking-wider">LIVE SYNTHESIS</span>
                  </div>

                  {/* Mid screen content */}
                  <div className="my-auto text-center space-y-3">
                    <div className="mx-auto h-12 w-12 rounded-full bg-[#2F5BEA] flex items-center justify-center animate-bounce shadow-lg cursor-pointer" onClick={() => setIsPlaying(!isPlaying)}>
                      {isPlaying ? <Icons.Pause className="h-5 w-5 text-white" /> : <Icons.Play className="h-5 w-5 text-white ml-0.5" />}
                    </div>
                    <p className="text-sm font-bold tracking-wide">"Let's trace process ready queues under dynamic load bounds..."</p>
                    <p className="text-[11px] text-slate-400">Speaker Voice: Kore (Academic Voice Module)</p>
                  </div>

                  {/* Bottom Controls */}
                  <div className="space-y-2 bg-black/40 p-2.5 rounded-xl backdrop-blur-xs">
                    <div className="h-1.5 w-full bg-slate-700 rounded-full cursor-pointer overflow-hidden">
                      <div className="bg-[#2F5BEA] h-full" style={{ width: `${videoProgress}%` }}></div>
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-300">
                      <span>02:15 / 07:45</span>
                      <span>1080p AI Rendered</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* QUIZ TAB */}
            {activeTool === 'quiz' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div className="flex justify-between items-center flex-wrap gap-2">
                  <div>
                    <h3 className="text-base font-extrabold text-[#0F3D91]">Personalized Practice Quiz</h3>
                    <p className="text-xs text-slate-400">Validate comprehension to earn bonus XP and unlock credentials.</p>
                  </div>

                  {quizSubmitted && (
                    <button
                      onClick={() => setShowCertificate(true)}
                      className="flex items-center gap-1.5 rounded-lg bg-green-100 text-green-800 px-3.5 py-1.5 text-xs font-black shadow-xs cursor-pointer hover:bg-green-200 transition-colors"
                    >
                      <Icons.Award className="h-4 w-4" />
                      View Certificate
                    </button>
                  )}
                </div>

                <div className="space-y-4">
                  {quizQuestions.map((q, idx) => (
                    <div key={q.id} className="rounded-2xl border border-slate-100 bg-slate-50 p-5 space-y-3.5">
                      <h4 className="text-sm font-extrabold text-[#0F3D91]">
                        Question {idx + 1}: <span className="font-semibold text-slate-700">{q.question}</span>
                      </h4>

                      {/* Options rendering for MCQ */}
                      {q.type === 'MCQ' && q.options && (
                        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                          {q.options.map((opt) => (
                            <label
                              key={opt}
                              className={`flex items-center gap-2.5 rounded-xl border p-3 text-xs font-semibold cursor-pointer select-none transition-all ${
                                answers[q.id] === opt
                                  ? 'border-[#2F5BEA] bg-[#EAF2FF] text-[#0F3D91]'
                                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <input
                                type="radio"
                                name={`q-${q.id}`}
                                checked={answers[q.id] === opt}
                                onChange={() => setAnswers(prev => ({ ...prev, [q.id]: opt }))}
                                disabled={quizSubmitted}
                                className="h-4 w-4 text-[#2F5BEA]"
                              />
                              {opt}
                            </label>
                          ))}
                        </div>
                      )}

                      {/* True/False Options */}
                      {q.type === 'TrueFalse' && (
                        <div className="flex gap-4">
                          {['True', 'False'].map((val) => (
                            <label
                              key={val}
                              className={`flex items-center gap-2.5 rounded-xl border px-5 py-2 text-xs font-semibold cursor-pointer select-none transition-all ${
                                answers[q.id] === val
                                  ? 'border-[#2F5BEA] bg-[#EAF2FF] text-[#0F3D91]'
                                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                              }`}
                            >
                              <input
                                type="radio"
                                name={`q-${q.id}`}
                                checked={answers[q.id] === val}
                                onChange={() => setAnswers(prev => ({ ...prev, [q.id]: val }))}
                                disabled={quizSubmitted}
                                className="h-4 w-4 text-[#2F5BEA]"
                              />
                              {val}
                            </label>
                          ))}
                        </div>
                      )}

                      {/* Fill Blank or Text inputs */}
                      {(q.type === 'FillBlank' || q.type === 'Short') && (
                        <input
                          type="text"
                          value={answers[q.id] || ''}
                          disabled={quizSubmitted}
                          onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                          className="w-full sm:max-w-md rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs outline-none focus:border-[#2F5BEA]"
                          placeholder="Type your answer..."
                        />
                      )}

                      {/* Explanation if submitted */}
                      {quizSubmitted && (
                        <div className="mt-2.5 rounded-xl bg-slate-100 p-3 text-xs leading-relaxed text-slate-600 border border-slate-200">
                          <p className="font-bold flex items-center gap-1">
                            {answers[q.id]?.toLowerCase() === q.correctAnswer.toLowerCase() ? (
                              <span className="text-green-600 flex items-center gap-1">
                                <Icons.Check className="h-3.5 w-3.5 stroke-[3px]" /> Correct
                              </span>
                            ) : (
                              <span className="text-red-600 flex items-center gap-1">
                                <Icons.X className="h-3.5 w-3.5 stroke-[3px]" /> Incorrect (Answer: {q.correctAnswer})
                              </span>
                            )}
                          </p>
                          <p className="mt-1">{q.explanation}</p>
                        </div>
                      )}
                    </div>
                  ))}

                  {!quizSubmitted ? (
                    <button
                      onClick={handleQuizSubmit}
                      className="w-full sm:w-auto rounded-xl bg-[#0F3D91] px-6 py-2.5 text-xs font-bold text-white shadow-md hover:bg-opacity-95 cursor-pointer"
                    >
                      Submit Quiz & Calculate Grade
                    </button>
                  ) : (
                    <div className="rounded-2xl bg-blue-50 border border-blue-100 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div>
                        <h4 className="text-sm font-black text-[#0F3D91]">Quiz Score: {quizScore} / {quizQuestions.length}</h4>
                        <p className="text-xs text-slate-500 mt-1">Consistency streak maintained! Earned <span className="font-bold text-[#2F5BEA]">+{quizScore * 50} XP</span>.</p>
                      </div>
                      <button
                        onClick={() => { setAnswers({}); setQuizSubmitted(false); }}
                        className="flex items-center gap-1 text-xs font-bold text-[#0F3D91] hover:underline cursor-pointer"
                      >
                        <Icons.RotateCcw className="h-3.5 w-3.5" /> Re-attempt Quiz
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* EXAM ANSWER GENERATOR TAB */}
            {activeTool === 'answer-gen' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="text-base font-extrabold text-[#0F3D91]">Exam Answer Adaptation Generator</h3>
                    <p className="text-xs text-slate-400">Dynamic length allocation scaling directly matching the required paper marks.</p>
                  </div>

                  {/* Marks selector */}
                  <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl p-1 shrink-0">
                    {([2, 4, 5, 8, 10, 15, 20] as const).map((marks) => (
                      <button
                        key={marks}
                        onClick={() => setSelectedMarks(marks)}
                        className={`px-2.5 py-1 text-xs font-black rounded-lg transition-all cursor-pointer ${
                          selectedMarks === marks
                            ? 'bg-[#0F3D91] text-white shadow-xs'
                            : 'text-slate-500 hover:text-[#0F3D91] hover:bg-slate-100'
                        }`}
                      >
                        {marks}M
                      </button>
                    ))}
                  </div>
                </div>

                {/* Adapted answers output view */}
                <div className="space-y-4 text-xs text-slate-700 leading-relaxed max-w-3xl">
                  <div className="rounded-xl border border-slate-100 bg-slate-50 p-4 font-mono select-all">
                    <p className="font-bold text-[#0F3D91] uppercase tracking-wider mb-2 text-[10px]">Orchestrated Output Outline</p>
                    <p className="font-semibold text-slate-500">Grading Target: {selectedMarks} Marks | Complexity Scale: {selectedMarks >= 10 ? 'Detailed Dissertation' : 'Short Core Answer'}</p>
                  </div>

                  <div className="prose prose-slate max-w-none space-y-4">
                    <div dangerouslySetInnerHTML={{ __html: examAnswer.intro.replace(/\n/g, '<br/>') }} />
                    <div dangerouslySetInnerHTML={{ __html: examAnswer.explanation.replace(/\n/g, '<br/>') }} />
                    <div dangerouslySetInnerHTML={{ __html: examAnswer.examples.replace(/\n/g, '<br/>') }} />
                    
                    {examAnswer.diagram && (
                      <pre className="rounded-xl bg-slate-900 p-4 text-emerald-400 font-mono text-[10px] overflow-x-auto leading-normal">
                        {examAnswer.diagram}
                      </pre>
                    )}
                    
                    <div dangerouslySetInnerHTML={{ __html: examAnswer.conclusion.replace(/\n/g, '<br/>') }} />
                  </div>
                </div>
              </div>
            )}

            {/* CONCEPT FLASHCARDS TAB */}
            {activeTool === 'flashcards' && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                <div>
                  <h3 className="text-base font-extrabold text-[#0F3D91]">Academic Review Flashcards</h3>
                  <p className="text-xs text-slate-400">Click any card below to flip and reveal target explanations.</p>
                </div>

                <div className="flex flex-col items-center justify-center py-6 space-y-6">
                  {/* Flip Card Stage */}
                  <div
                    onClick={() => setIsFlipped(!isFlipped)}
                    className="h-44 w-full max-w-sm rounded-3xl border-2 border-slate-200 bg-white shadow-lg cursor-pointer p-6 flex flex-col items-center justify-center text-center transition-all duration-300 transform select-none hover:border-[#2F5BEA] relative"
                  >
                    <span className="absolute top-4 right-4 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                      {isFlipped ? 'Answer Screen' : 'Prompt Question'}
                    </span>

                    {!isFlipped ? (
                      <h4 className="text-base font-extrabold text-[#0F3D91] px-2 leading-relaxed">
                        {flashcards[activeFlashcard].front}
                      </h4>
                    ) : (
                      <p className="text-xs text-slate-600 leading-relaxed font-semibold px-2">
                        {flashcards[activeFlashcard].back}
                      </p>
                    )}

                    <span className="absolute bottom-4 text-[10px] font-bold text-[#2F5BEA] flex items-center gap-1">
                      <Icons.RotateCcw className="h-3 w-3" /> Click to Flip Card
                    </span>
                  </div>

                  {/* Nav */}
                  <div className="flex items-center gap-3">
                    <button
                      disabled={activeFlashcard === 0}
                      onClick={() => { setActiveFlashcard(prev => prev-1); setIsFlipped(false); }}
                      className="p-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                    >
                      <Icons.ChevronRight className="h-4 w-4 rotate-180" />
                    </button>
                    <span className="text-xs text-slate-400 font-bold">{activeFlashcard+1} / {flashcards.length}</span>
                    <button
                      disabled={activeFlashcard === flashcards.length - 1}
                      onClick={() => { setActiveFlashcard(prev => prev+1); setIsFlipped(false); }}
                      className="p-2 border border-slate-200 bg-white rounded-xl hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                    >
                      <Icons.ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT SIDEBAR: AGENT MONITOR & LIVE CONSOLE */}
        <div className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-slate-200 bg-white p-4 flex flex-col gap-4">
          <div className="space-y-0.5">
            <h3 className="text-xs font-extrabold uppercase tracking-widest text-[#2F5BEA]">
              Platform Orchestration
            </h3>
            <h4 className="text-sm font-black text-[#0F3D91]">
              Active Multi-Agent Pool
            </h4>
          </div>

          {/* List of active agents and thinking progress */}
          <div className="space-y-2 max-h-48 lg:max-h-none overflow-y-auto pr-1">
            {agents.map((agent) => (
              <div key={agent.id} className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 flex items-center justify-between gap-2.5 hover:border-slate-200 transition-all">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-lg bg-blue-50 text-[#0F3D91] flex items-center justify-center border border-blue-100 shrink-0">
                    <Icons.Cpu className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-xs font-extrabold text-[#0F3D91]">{agent.name}</p>
                    <p className="text-[9px] text-slate-400">{agent.role}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className={`inline-block rounded-md px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-wide ${
                    agent.status === 'completed' ? 'bg-green-100 text-green-800' :
                    agent.status === 'running' ? 'bg-[#EAF2FF] text-[#0F3D91] animate-pulse' :
                    'bg-slate-100 text-slate-400'
                  }`}>
                    {agent.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Console logger terminal */}
          <div className="border-t border-slate-100 pt-3 flex-1 flex flex-col gap-2 min-h-[150px] lg:min-h-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Collaborative Agent Logs</p>
            <div className="flex-1 bg-slate-950 rounded-2xl p-3 font-mono text-[9px] text-emerald-400 space-y-1.5 overflow-y-auto max-h-40 lg:max-h-none select-text border border-slate-800 leading-normal">
              {agentLogs.map((log, index) => (
                <div key={index} className="border-l-2 border-emerald-900 pl-1.5">
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* COMPLETED CERTIFICATE OVERLAY MODAL */}
      {showCertificate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-2xl rounded-3xl border border-slate-200 bg-white p-8 md:p-12 text-center shadow-2xl space-y-6 relative overflow-hidden">
            <button onClick={() => setShowCertificate(false)} className="absolute top-4 right-4 p-2 bg-slate-50 hover:bg-slate-100 rounded-full cursor-pointer">
              <Icons.X className="h-5 w-5 text-slate-500" />
            </button>

            {/* Custom SVG Certificate frame */}
            <div className="border-4 border-double border-[#0F3D91] p-6 space-y-4">
              <div className="flex justify-center">
                <Icons.Award className="h-14 w-14 text-amber-500 animate-bounce" />
              </div>

              <span className="text-xs font-black uppercase tracking-widest text-[#2F5BEA]">EduAgent Academy</span>
              <h2 className="text-2xl font-black text-[#0F3D91]">CERTIFICATE OF STUDY MASTER</h2>
              
              <div className="h-px w-24 bg-slate-200 mx-auto"></div>

              <p className="text-xs text-slate-500 leading-relaxed">
                This academic credential verifies that our dynamic multi-agent orchestrator evaluated, processed, and validated comprehension on the specialized syllabus topic of
              </p>
              
              <p className="text-lg font-extrabold text-[#2F5BEA] italic">"{topic}"</p>

              <p className="text-[10px] text-slate-400">Awarded to student profile: <span className="font-bold text-slate-700">Alex Mercer</span> on July 17, 2026.</p>
            </div>

            <button
              onClick={() => { window.print(); }}
              className="rounded-xl bg-[#0F3D91] px-6 py-2.5 text-xs font-bold text-white shadow-md hover:bg-opacity-95 cursor-pointer flex items-center justify-center gap-2 mx-auto"
            >
              <Icons.Download className="h-4 w-4" /> Download Printable Notes PDF
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
