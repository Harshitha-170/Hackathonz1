/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import { PageId } from '../types';

interface HeaderProps {
  currentTab: PageId;
  setCurrentTab: (tab: PageId) => void;
  streak: number;
  xp: number;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, setCurrentTab, streak, xp, onLogout }) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    { id: 1, text: 'Agent Planner compiled Day 3 materials.', time: '2 mins ago' },
    { id: 2, text: 'You unlocked the "Agent Commander" badge!', time: '1 hour ago' },
    { id: 3, text: 'Daily learning recommendation updated.', time: '4 hours ago' }
  ];

  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white px-4 md:px-6 shadow-xs">
      {/* Left section: Logo */}
      <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setCurrentTab('dashboard')}>
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#0F3D91] text-white">
          <Icons.Cpu className="h-5 w-5 animate-pulse" />
        </div>
        <span className="text-xl font-bold tracking-tight text-[#0F3D91]">
          EduAgent <span className="text-[#2F5BEA]">AI</span>
        </span>
        <span className="hidden sm:inline-block rounded-md bg-[#EAF2FF] px-2 py-0.5 text-xs font-semibold text-[#0F3D91]">
          Multi-Agent v1.2
        </span>
      </div>

      {/* Center: Search indicator */}
      <div className="hidden max-w-xs md:flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-500 hover:border-slate-300 transition-colors cursor-pointer" onClick={() => setCurrentTab('dashboard')}>
        <Icons.Search className="h-4 w-4" />
        <span>Ask agents anything...</span>
      </div>

      {/* Right: Stats, Alerts & Profile */}
      <div className="flex items-center gap-3 md:gap-5">
        {/* Streak Indicator */}
        <div className="flex items-center gap-1.5 rounded-lg bg-orange-50 px-2.5 py-1 text-xs font-semibold text-orange-600 border border-orange-100">
          <Icons.Flame className="h-4 w-4 fill-orange-500 text-orange-500" />
          <span>{streak} Day Streak</span>
        </div>

        {/* XP Count */}
        <div className="flex items-center gap-1.5 rounded-lg bg-blue-50 px-2.5 py-1 text-xs font-semibold text-[#0F3D91] border border-blue-100">
          <Icons.Award className="h-4 w-4 text-[#2F5BEA]" />
          <span>{xp} XP</span>
        </div>

        {/* Notifications */}
        <div className="relative">
          <button 
            id="notification-bell-btn"
            onClick={() => { setShowNotifications(!showNotifications); setShowProfileMenu(false); }}
            className="relative p-1.5 text-slate-500 hover:text-[#0F3D91] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <Icons.Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500"></span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2.5 w-80 rounded-2xl border border-slate-200 bg-white py-2 shadow-xl z-50">
              <div className="flex items-center justify-between px-4 py-1.5 border-b border-slate-100">
                <span className="font-bold text-[#0F3D91] text-sm">Notifications</span>
                <span className="text-xs text-[#2F5BEA] cursor-pointer hover:underline">Mark all read</span>
              </div>
              <div className="divide-y divide-slate-50 max-h-60 overflow-y-auto">
                {notifications.map((n) => (
                  <div key={n.id} className="p-3 text-xs text-slate-600 hover:bg-slate-50 transition-colors">
                    <p className="font-medium text-slate-800">{n.text}</p>
                    <span className="text-slate-400 mt-1 block">{n.time}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Profile Dropdown */}
        <div className="relative">
          <button 
            id="profile-dropdown-btn"
            onClick={() => { setShowProfileMenu(!showProfileMenu); setShowNotifications(false); }}
            className="flex items-center gap-2 rounded-full p-1 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <div className="h-8 w-8 rounded-full bg-[#EAF2FF] border border-slate-200 flex items-center justify-center text-[#0F3D91] font-bold text-xs">
              AM
            </div>
            <Icons.ChevronDown className="h-4 w-4 text-slate-500" />
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2.5 w-56 rounded-2xl border border-slate-200 bg-white py-1.5 shadow-xl z-50">
              <div className="px-4 py-2.5 border-b border-slate-100">
                <p className="font-bold text-[#0F3D91] text-sm">Alex Mercer</p>
                <p className="text-xs text-slate-500">alex.mercer@university.edu</p>
              </div>
              <button 
                onClick={() => { setCurrentTab('profile'); setShowProfileMenu(false); }}
                className="flex w-full items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
              >
                <Icons.User className="h-4 w-4 text-[#2F5BEA]" />
                Profile & Settings
              </button>
              <button 
                onClick={() => { setCurrentTab('achievements'); setShowProfileMenu(false); }}
                className="flex w-full items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
              >
                <Icons.Award className="h-4 w-4 text-[#2F5BEA]" />
                My Achievements
              </button>
              <button 
                onClick={() => { setCurrentTab('progress'); setShowProfileMenu(false); }}
                className="flex w-full items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left cursor-pointer"
              >
                <Icons.Activity className="h-4 w-4 text-[#2F5BEA]" />
                Progress Analytics
              </button>
              <div className="h-px bg-slate-100 my-1"></div>
              <button 
                onClick={() => { onLogout(); setShowProfileMenu(false); }}
                className="flex w-full items-center gap-2.5 px-4 py-2 text-sm text-red-600 hover:bg-red-50 text-left cursor-pointer"
              >
                <Icons.LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

interface SidebarProps {
  currentTab: PageId;
  setCurrentTab: (tab: PageId) => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, setCurrentTab, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
    { id: 'workspace', label: 'Learning Workspace', icon: 'BookOpen' },
    { id: 'achievements', label: 'Achievements', icon: 'Award' },
    { id: 'progress', label: 'Progress Analytics', icon: 'Activity' },
    { id: 'profile', label: 'Profile Settings', icon: 'User' }
  ];

  return (
    <aside className="hidden md:flex h-[calc(100vh-4rem)] w-64 flex-col border-r border-slate-200 bg-white p-4">
      <div className="flex-1 space-y-1">
        {menuItems.map((item) => {
          const IconComponent = (Icons as any)[item.icon];
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id as PageId)}
              className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#EAF2FF] text-[#0F3D91] shadow-xs'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-[#0F3D91]'
              }`}
            >
              {IconComponent && <IconComponent className={`h-5 w-5 ${isActive ? 'text-[#2F5BEA]' : ''}`} />}
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="border-t border-slate-100 pt-4">
        <button
          onClick={onLogout}
          className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
        >
          <Icons.LogOut className="h-5 w-5" />
          Logout Account
        </button>
      </div>
    </aside>
  );
};
