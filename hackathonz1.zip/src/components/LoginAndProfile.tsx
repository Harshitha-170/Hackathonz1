/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import { AcademicProfile, EducationLevel, LearningPlanDay } from '../types';

interface LoginProps {
  onLogin: (email: string) => void;
}

export const LoginPage: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('alex.mercer@university.edu');
  const [password, setPassword] = useState('password123');
  const [rememberMe, setRememberMe] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      onLogin(email);
    }
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-slate-50 p-4 md:p-8">
      <div className="flex w-full max-w-5xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl md:flex-row">
        
        {/* Left Side: Dynamic Illustration */}
        <div className="hidden w-1/2 flex-col justify-between bg-[#0F3D91] p-10 text-white md:flex">
          <div className="flex items-center gap-2">
            <Icons.Cpu className="h-7 w-7 text-[#EAF2FF] animate-pulse" />
            <span className="text-xl font-bold tracking-tight">EduAgent AI</span>
          </div>

          <div className="my-auto space-y-6">
            <div className="relative flex justify-center py-6">
              {/* Custom SVG Learning Agents Art */}
              <svg viewBox="0 0 200 200" className="h-48 w-48">
                <circle cx="100" cy="100" r="70" fill="none" stroke="#2F5BEA" strokeWidth="4" strokeDasharray="5 5" className="animate-spin" style={{ animationDuration: '30s' }} />
                <circle cx="100" cy="100" r="50" fill="#1b4fac" />
                <path d="M70 100 Q100 60 130 100 T190 100" fill="none" stroke="#EAF2FF" strokeWidth="3" />
                {/* Agent satellites */}
                <circle cx="100" cy="30" r="14" fill="#2F5BEA" />
                <circle cx="160" cy="140" r="12" fill="#38BDF8" />
                <circle cx="40" cy="140" r="10" fill="#EAF2FF" />
                <circle cx="100" cy="100" r="25" fill="#0F3D91" />
                {/* Book & CPU blend icon inside */}
                <path d="M92 92 h16 v16 h-16 z" fill="#38BDF8" opacity="0.8" />
              </svg>
            </div>
            
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-extrabold tracking-tight">
                Learn Smarter with Multi-Agent AI
              </h1>
              <p className="text-sm text-blue-200">
                A collaborative network of specialized AI agents built to analyze documentation, draft interactive mind maps, formulate procedural flowcharts, and tailor study tracks directly to your syllabus.
              </p>
            </div>
          </div>

          <div className="text-xs text-blue-300">
            Approved by Leading Global Academics &copy; 2026 EduAgent.
          </div>
        </div>

        {/* Right Side: Login Form */}
        <div className="flex w-full flex-col justify-center p-8 md:w-1/2 md:p-12">
          <div className="mb-8 md:hidden">
            <div className="flex items-center gap-2 text-[#0F3D91]">
              <Icons.Cpu className="h-6 w-6" />
              <span className="text-lg font-bold">EduAgent AI</span>
            </div>
          </div>

          <div className="mb-6 space-y-1">
            <h2 className="text-2xl font-extrabold text-[#0F3D91]">Welcome back</h2>
            <p className="text-sm text-slate-500">Sign in to your personalized academy</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Icons.User className="absolute top-3 left-3 h-4 w-4 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 py-2.5 pr-4 pl-10 text-sm outline-none focus:border-[#2F5BEA] focus:ring-1 focus:ring-[#2F5BEA]"
                  placeholder="alex.mercer@university.edu"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                  Password
                </label>
                <a href="#forgot" className="text-xs font-semibold text-[#2F5BEA] hover:underline">
                  Forgot Password?
                </a>
              </div>
              <div className="relative">
                <Icons.Lock className="absolute top-3 left-3 h-4 w-4 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 py-2.5 pr-4 pl-10 text-sm outline-none focus:border-[#2F5BEA] focus:ring-1 focus:ring-[#2F5BEA]"
                  placeholder="••••••••••••"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-slate-600 select-none cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={() => setRememberMe(!rememberMe)}
                  className="h-4 w-4 rounded border-slate-300 text-[#2F5BEA] focus:ring-[#2F5BEA]"
                />
                Remember Me
              </label>
            </div>

            <button
              type="submit"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#0F3D91] py-2.5 text-sm font-bold text-white shadow-md hover:bg-opacity-95 transition-all cursor-pointer"
            >
              Sign In with Credentials
              <Icons.ArrowRight className="h-4 w-4" />
            </button>
          </form>

          {/* Social Logins */}
          <div className="mt-6">
            <div className="relative flex items-center justify-center py-2">
              <div className="absolute w-full border-t border-slate-200"></div>
              <span className="relative bg-white px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Or Continue With
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <button
                onClick={() => onLogin('google.user@gmail.com')}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Google SSO
              </button>
              <button
                onClick={() => onLogin('microsoft.user@outlook.com')}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                <svg className="h-4 w-4" viewBox="0 0 23 23">
                  <path fill="#f35325" d="M0 0h11v11H0z"/>
                  <path fill="#81bc06" d="M12 0h11v11H12z"/>
                  <path fill="#05a6f0" d="M0 12h11v11H0z"/>
                  <path fill="#ffba08" d="M12 12h11v11H12z"/>
                </svg>
                Microsoft SSO
              </button>
            </div>
          </div>

          <p className="mt-8 text-center text-xs text-slate-500">
            Don't have an account?{' '}
            <a href="#signup" className="font-bold text-[#2F5BEA] hover:underline">
              Create student profile
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

interface ProfileSetupProps {
  onSave: (profile: AcademicProfile) => void;
}

export const AcademicProfileSetup: React.FC<ProfileSetupProps> = ({ onSave }) => {
  const [level, setLevel] = useState<EducationLevel>('Degree');
  const [classNumber, setClassNumber] = useState('8');
  const [board, setBoard] = useState('CBSE');
  const [stream, setStream] = useState('MPC');
  const [degree, setDegree] = useState('B.Tech');
  const [branch, setBranch] = useState('CSE');

  const handleSave = () => {
    onSave({
      level,
      classNumber: level === 'Class 1-5' || level === 'Class 6-10' ? classNumber : undefined,
      board: level === 'Intermediate' ? board : undefined,
      stream: level === 'Intermediate' ? stream : undefined,
      degree: level === 'Degree' ? degree : undefined,
      branch: level === 'Degree' && degree === 'B.Tech' ? branch : undefined
    });
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-xl rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">
        <div className="text-center mb-6">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#EAF2FF] text-[#0F3D91] mb-3">
            <Icons.GraduationCap className="h-6 w-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-[#0F3D91]">Let's Personalize Your Learning</h2>
          <p className="text-sm text-slate-500 mt-1">Our dynamic multi-agent system tailors answers and roadmaps specifically to your academic tier.</p>
        </div>

        <div className="space-y-5">
          {/* 1. Level of Education */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">
              Current Education Level
            </label>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
              {(['Class 1-5', 'Class 6-10', 'Intermediate', 'Degree', 'Post Graduation'] as EducationLevel[]).map((lev) => (
                <button
                  key={lev}
                  type="button"
                  onClick={() => setLevel(lev)}
                  className={`rounded-xl border p-3 text-center text-xs font-bold transition-all cursor-pointer ${
                    level === lev
                      ? 'border-[#2F5BEA] bg-[#EAF2FF] text-[#0F3D91] shadow-xs'
                      : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {lev}
                </button>
              ))}
            </div>
          </div>

          {/* Conditional Dropdown for Class 1-5 / 6-10 */}
          {(level === 'Class 1-5' || level === 'Class 6-10') && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                Choose Class Number
              </label>
              <select
                value={classNumber}
                onChange={(e) => setClassNumber(e.target.value)}
                className="w-full rounded-xl border border-slate-200 p-2.5 text-sm outline-none focus:border-[#2F5BEA]"
              >
                {level === 'Class 1-5'
                  ? ['1', '2', '3', '4', '5'].map((c) => <option key={c} value={c}>Class {c}</option>)
                  : ['6', '7', '8', '9', '10'].map((c) => <option key={c} value={c}>Class {c}</option>)}
              </select>
            </div>
          )}

          {/* Conditional Dropdown for Intermediate */}
          {level === 'Intermediate' && (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Select Board
                </label>
                <select
                  value={board}
                  onChange={(e) => setBoard(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 text-sm outline-none focus:border-[#2F5BEA]"
                >
                  <option value="CBSE">CBSE (Central Board)</option>
                  <option value="ICSE">ICSE</option>
                  <option value="State Board">State Board</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Select Stream
                </label>
                <select
                  value={stream}
                  onChange={(e) => setStream(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 text-sm outline-none focus:border-[#2F5BEA]"
                >
                  <option value="MPC">MPC (Maths, Physics, Chemistry)</option>
                  <option value="BiPC">BiPC (Biology, Physics, Chemistry)</option>
                  <option value="CEC">CEC (Civics, Economics, Commerce)</option>
                  <option value="HEC">HEC (History, Economics, Civics)</option>
                  <option value="MEC">MEC (Maths, Economics, Commerce)</option>
                </select>
              </div>
            </div>
          )}

          {/* Conditional Dropdown for Degree */}
          {level === 'Degree' && (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Select Degree
                </label>
                <select
                  value={degree}
                  onChange={(e) => setDegree(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 text-sm outline-none focus:border-[#2F5BEA]"
                >
                  <option value="B.Tech">B.Tech / B.E.</option>
                  <option value="B.Sc">B.Sc</option>
                  <option value="B.Com">B.Com</option>
                  <option value="BBA">BBA</option>
                  <option value="BA">BA</option>
                  <option value="BCA">BCA</option>
                </select>
              </div>

              {degree === 'B.Tech' && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                    Select Branch
                  </label>
                  <select
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 text-sm outline-none focus:border-[#2F5BEA]"
                  >
                    <option value="CSE">Computer Science (CSE)</option>
                    <option value="AI & ML">Artificial Intelligence & ML</option>
                    <option value="Data Science">Data Science</option>
                    <option value="ECE">ECE (Electronics & Comm)</option>
                    <option value="EEE">EEE (Electrical & Electronics)</option>
                    <option value="Mechanical">Mechanical Engineering</option>
                    <option value="Civil">Civil Engineering</option>
                    <option value="IT">Information Technology</option>
                    <option value="Cyber Security">Cyber Security</option>
                  </select>
                </div>
              )}
            </div>
          )}

          <button
            onClick={handleSave}
            className="w-full rounded-xl bg-[#0F3D91] py-3 text-sm font-bold text-white shadow-lg hover:bg-opacity-95 transition-all mt-6 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Icons.Cpu className="h-4 w-4" />
            Save Profile & Generate Learning Plan
          </button>
        </div>
      </div>
    </div>
  );
};

interface RoadmapProps {
  topic: string;
  roadmap: LearningPlanDay[];
  onStart: () => void;
}

export const LearningRoadmap: React.FC<RoadmapProps> = ({ topic, roadmap, onStart }) => {
  return (
    <div className="mx-auto w-full max-w-4xl p-4 md:p-8">
      <div className="mb-8 flex flex-col items-center justify-between gap-4 rounded-2xl bg-white border border-slate-200 p-6 md:flex-row shadow-sm">
        <div className="space-y-1 text-center md:text-left">
          <span className="rounded-full bg-[#EAF2FF] px-3 py-1 text-xs font-bold text-[#0F3D91]">
            AI-GENERATED ACADEMIC SYLLABUS
          </span>
          <h2 className="text-2xl font-extrabold text-[#0F3D91] mt-2">
            Recommended 7-Day Plan: <span className="text-[#2F5BEA]">{topic}</span>
          </h2>
          <p className="text-sm text-slate-500">
            Synthesized dynamically by the Learning Planner Agent, Topic Analyzer Agent, and Research Agent.
          </p>
        </div>

        <button
          onClick={onStart}
          className="flex items-center gap-2 rounded-xl bg-[#0F3D91] px-5 py-2.5 text-sm font-bold text-white shadow-md hover:bg-opacity-95 transition-all cursor-pointer"
        >
          Begin Roadmap Study
          <Icons.ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Vertical Timeline */}
      <div className="relative space-y-6 pl-6 md:pl-10 before:absolute before:top-4 before:bottom-4 before:left-3 md:before:left-[19px] before:w-0.5 before:bg-slate-200">
        {roadmap.map((day, idx) => (
          <div key={day.day} className="relative group">
            {/* Timeline Node Point */}
            <div className="absolute -left-9 md:-left-12 flex h-6 w-6 items-center justify-center rounded-full bg-white border-2 border-[#2F5BEA] text-xs font-bold text-[#0F3D91] shadow-xs group-hover:scale-110 transition-transform">
              {day.day}
            </div>

            {/* Timeline Card */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 hover:border-slate-300 transition-all shadow-xs">
              <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#2F5BEA]">
                      Day {day.day}
                    </span>
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-300"></span>
                    <span className="text-xs text-slate-500 font-medium">
                      Est: {day.duration}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-[#0F3D91]">{day.title}</h3>
                </div>

                <div className="flex items-center gap-2.5">
                  <span className={`rounded-md px-2.5 py-0.5 text-xs font-bold ${
                    day.difficulty === 'Easy' ? 'bg-green-50 text-green-700' :
                    day.difficulty === 'Medium' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-700'
                  }`}>
                    {day.difficulty}
                  </span>
                  
                  <button
                    onClick={onStart}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-bold text-slate-700 hover:border-[#2F5BEA] hover:bg-[#EAF2FF] hover:text-[#0F3D91] transition-all cursor-pointer"
                  >
                    Start Day
                  </button>
                </div>
              </div>

              {/* Day's Core Objectives */}
              <div className="mt-4 border-t border-slate-50 pt-3">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Syllabus Milestones</p>
                <div className="flex flex-wrap gap-2">
                  {day.objectives.map((obj, oIdx) => (
                    <span key={oIdx} className="flex items-center gap-1 rounded-md bg-slate-50 px-2.5 py-1 text-xs text-slate-600 border border-slate-100">
                      <Icons.CheckCircle className="h-3 w-3 text-green-500" />
                      {obj}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
