/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PageId = 'login' | 'profile-setup' | 'roadmap' | 'dashboard' | 'workspace' | 'achievements' | 'progress' | 'profile';

export type EducationLevel = 'Class 1-5' | 'Class 6-10' | 'Intermediate' | 'Degree' | 'Post Graduation';

export interface AcademicProfile {
  level: EducationLevel;
  classNumber?: string;
  board?: string;
  stream?: string;
  degree?: string;
  branch?: string;
}

export interface LearningPlanDay {
  day: number;
  title: string;
  duration: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  progress: number; // 0 to 100
  objectives: string[];
}

export type AgentStatus = 'idle' | 'thinking' | 'running' | 'completed';

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  icon: string;
  status: AgentStatus;
  progress: number;
  outputLog: string[];
}

export interface LearningResource {
  summary: string;
  keyConcepts: { title: string; desc: string }[];
  definitions: { term: string; meaning: string }[];
  examples: { title: string; scenario: string; steps: string[] }[];
  applications: string[];
  interviewQuestions: { q: string; a: string }[];
  realWorldUses: { title: string; desc: string }[];
}

export interface MindMapNode {
  id: string;
  label: string;
  x: number;
  y: number;
  color: string;
  type: 'root' | 'category' | 'detail';
}

export interface MindMapLink {
  source: string;
  target: string;
}

export interface FlowchartStep {
  id: string;
  title: string;
  description: string;
  type: 'start' | 'process' | 'decision' | 'end';
}

export interface QuizQuestion {
  id: number;
  type: 'MCQ' | 'TrueFalse' | 'FillBlank' | 'Short' | 'Long';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  xpValue: number;
  unlockedAt?: string;
  progress?: number;
  maxProgress?: number;
}
