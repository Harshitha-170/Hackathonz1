/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import { PageId, AcademicProfile, LearningPlanDay, LearningResource, MindMapNode, MindMapLink, FlowchartStep, QuizQuestion } from './types';
import { generateCustomLearning } from './mockData';
import { Header, Sidebar } from './components/HeaderAndSidebar';
import { LoginPage, AcademicProfileSetup, LearningRoadmap } from './components/LoginAndProfile';
import { AchievementsPage, ProgressPage } from './components/ProgressAndAchievements';
import { WorkspacePage } from './components/WorkspacePage';

export default function App() {
  // Authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [academicProfile, setAcademicProfile] = useState<AcademicProfile | null>(null);

  // Global routing
  const [currentPage, setCurrentPage] = useState<PageId>('login');

  // Multi-Agent states
  const [topic, setTopic] = useState('Operating Systems Scheduling Algorithms');
  const [searchQuery, setSearchQuery] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Core generated outputs
  const [learningResource, setLearningResource] = useState<LearningResource>(() => generateCustomLearning(topic).summary ? (generateCustomLearning(topic) as any) : {} as any);
  const [roadmap, setRoadmap] = useState<LearningPlanDay[]>(() => generateCustomLearning(topic).roadmap || []);
  const [mindMapNodes, setMindMapNodes] = useState<MindMapNode[]>(() => generateCustomLearning(topic).mindMapNodes || []);
  const [mindMapLinks, setMindMapLinks] = useState<MindMapLink[]>(() => generateCustomLearning(topic).mindMapLinks || []);
  const [flowchartSteps, setFlowchartSteps] = useState<FlowchartStep[]>(() => generateCustomLearning(topic).flowchartSteps || []);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(() => generateCustomLearning(topic).quizQuestions || []);

  // Gamification metrics
  const [xp, setXp] = useState(1250);
  const [streak, setStreak] = useState(7);

  // Extra helper features state
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>(['Operating Systems Scheduling Algorithms']);

  // Handle login
  const handleLogin = (email: string) => {
    setUserEmail(email);
    setIsLoggedIn(true);
    setCurrentPage('profile-setup');
  };

  // Handle profile save
  const handleProfileSave = (profile: AcademicProfile) => {
    setAcademicProfile(profile);
    // Initialize standard roadmap based on topic
    const payload = generateCustomLearning(topic);
    setLearningResource(payload as any);
    setRoadmap(payload.roadmap);
    setMindMapNodes(payload.mindMapNodes);
    setMindMapLinks(payload.mindMapLinks);
    setFlowchartSteps(payload.flowchartSteps);
    setQuizQuestions(payload.quizQuestions);
    setCurrentPage('roadmap');
  };

  // Handle start study
  const handleStartRoadmapStudy = () => {
    setCurrentPage('dashboard');
  };

  // Handle search & orchestrate agents
  const handleSearchTrigger = (overrideTopic?: string) => {
    const query = overrideTopic || searchQuery;
    if (!query.trim()) return;

    setTopic(query);
    setSearchQuery('');
    setIsGenerating(true);
    setCurrentPage('workspace');

    // Load custom parsed templates
    const payload = generateCustomLearning(query);
    setLearningResource(payload as any);
    setRoadmap(payload.roadmap);
    setMindMapNodes(payload.mindMapNodes);
    setMindMapLinks(payload.mindMapLinks);
    setFlowchartSteps(payload.flowchartSteps);
    setQuizQuestions(payload.quizQuestions);

    // Simulate completion
    setTimeout(() => {
      setIsGenerating(false);
      setXp(prev => prev + 100);
    }, 6000);
  };

  // Handle drag over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Handle drop file simulated
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setAttachedFiles(prev => [...prev, 'Syllabus_SyllabusFile_2026.pdf']);
  };

  const handleFileAttachSimulator = (filename: string) => {
    setAttachedFiles(prev => [...prev, filename]);
  };

  // Toggle bookmark
  const toggleBookmark = (bTopic: string) => {
    if (bookmarks.includes(bTopic)) {
      setBookmarks(bookmarks.filter(b => b !== bTopic));
    } else {
      setBookmarks([...bookmarks, bTopic]);
    }
  };

  return (
    <div className="min-h-screen w-full bg-slate-50 font-sans text-slate-800 antialiased select-none">
      
      {/* 1. Login Stage */}
      {currentPage === 'login' && (
        <LoginPage onLogin={handleLogin} />
      )}

      {/* 2. Profile Setup Stage */}
      {currentPage === 'profile-setup' && (
        <AcademicProfileSetup onSave={handleProfileSave} />
      )}

      {/* 3. Generated Timeline Roadmap Stage */}
      {currentPage === 'roadmap' && (
        <div className="flex flex-col min-h-screen">
          <Header currentTab={currentPage} setCurrentTab={setCurrentPage} streak={streak} xp={xp} onLogout={() => setCurrentPage('login')} />
          <div className="flex-1 overflow-y-auto bg-slate-50 py-6">
            <LearningRoadmap topic={topic} roadmap={roadmap} onStart={handleStartRoadmapStudy} />
          </div>
        </div>
      )}

      {/* 4. MAIN INNER ACADEMY PAGES (Dashboard, Workspace, Achievements, Progress, Profile) */}
      {['dashboard', 'workspace', 'achievements', 'progress', 'profile'].includes(currentPage) && (
        <div className="flex h-screen flex-col overflow-hidden bg-white">
          <Header currentTab={currentPage} setCurrentTab={setCurrentPage} streak={streak} xp={xp} onLogout={() => setCurrentPage('login')} />
          
          <div className="flex flex-1 overflow-hidden">
            {/* Navigation Sidebar */}
            <Sidebar currentTab={currentPage} setCurrentTab={setCurrentPage} onLogout={() => setCurrentPage('login')} />

            {/* Render sub views */}
            <main className="flex-1 overflow-y-auto bg-slate-50">
              
              {/* DASHBOARD PAGE */}
              {currentPage === 'dashboard' && (
                <div className="space-y-6 p-4 md:p-6 max-w-5xl mx-auto">
                  <div className="flex flex-col gap-1">
                    <h1 className="text-2xl font-black text-[#0F3D91]">Interactive Learning Platform</h1>
                    <p className="text-sm text-slate-500">Provide an objective to coordinate, create, and launch our dynamic agent suite.</p>
                  </div>

                  {/* Primary Central Chat Input */}
                  <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-md space-y-4">
                    <div className="space-y-1">
                      <h3 className="text-base font-extrabold text-[#0F3D91]">What would you like to learn today?</h3>
                      <p className="text-xs text-slate-400">Our agents will automatically create plans, interactive mind maps, and quiz items.</p>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter') handleSearchTrigger(); }}
                        placeholder="Ask agents anything (e.g. Learn Operating Systems Scheduling Algorithms)..."
                        className="w-full rounded-2xl border border-slate-200 py-3.5 pl-4 pr-14 text-sm outline-none focus:border-[#2F5BEA] focus:ring-1 focus:ring-[#2F5BEA]"
                      />
                      <button
                        onClick={() => handleSearchTrigger()}
                        className="absolute right-2 top-2 h-10 w-10 rounded-xl bg-[#0F3D91] text-white flex items-center justify-center hover:bg-opacity-95 transition-all cursor-pointer"
                      >
                        <Icons.ArrowRight className="h-5 w-5" />
                      </button>
                    </div>

                    {/* Attachment buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
                      <div className="flex flex-wrap gap-1.5">
                        <button onClick={() => setShowCameraModal(true)} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer">
                          <Icons.Camera className="h-3.5 w-3.5 text-[#2F5BEA]" />
                          Snapshot Camera
                        </button>
                        <button onClick={() => setShowVoiceModal(true)} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer">
                          <Icons.Mic className="h-3.5 w-3.5 text-[#2F5BEA]" />
                          Audio Input
                        </button>
                        <button onClick={() => handleFileAttachSimulator('Syllabus_ComputerArchitecture.pdf')} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer">
                          <Icons.FileText className="h-3.5 w-3.5 text-red-500" />
                          Upload PDF
                        </button>
                        <button onClick={() => handleFileAttachSimulator('LessonPlan_Quantum.pptx')} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer">
                          <Icons.FileImage className="h-3.5 w-3.5 text-orange-500" />
                          Upload PPT
                        </button>
                      </div>

                      {attachedFiles.length > 0 && (
                        <span className="text-[10px] bg-blue-50 text-[#0F3D91] px-2.5 py-1 rounded-md font-bold">
                          {attachedFiles.length} File(s) Attached
                        </span>
                      )}
                    </div>

                    {/* Drag and drop area simulator */}
                    <div
                      onDragOver={handleDragOver}
                      onDrop={handleDrop}
                      className="border border-dashed border-slate-200 rounded-2xl bg-slate-50 p-6 text-center hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      <Icons.UploadCloud className="h-8 w-8 mx-auto text-slate-400" />
                      <p className="text-xs font-bold text-slate-600 mt-2">Drag and drop secondary documents here</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">Supports PDF, PPTX, DOCX, and images up to 50MB</p>
                    </div>
                  </div>

                  {/* Recommended & Streak Board */}
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {/* Recommended topics */}
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3 shadow-xs">
                      <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Recommended Syllabus Topics</h3>
                      <div className="space-y-2">
                        {[
                          { title: 'Quantum Computing Qubits', desc: 'Explore superposition, logic gates and state noise.' },
                          { title: 'Photosynthesis in Plants', desc: 'Syllabus on light reactions and electron cycles.' },
                          { title: 'Database Relational Normalization', desc: 'Normalization rules (1NF, 2NF, 3NF, BCNF) and tables.' }
                        ].map((rec) => (
                          <div
                            key={rec.title}
                            onClick={() => handleSearchTrigger(rec.title)}
                            className="p-3 border border-slate-50 rounded-xl bg-slate-50 hover:bg-blue-50/50 hover:border-blue-100 transition-all cursor-pointer text-left"
                          >
                            <h4 className="text-xs font-extrabold text-[#0F3D91]">{rec.title}</h4>
                            <p className="text-[10px] text-slate-500 mt-0.5">{rec.desc}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* General goals & streaks */}
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs flex flex-col justify-between">
                      <div className="space-y-3">
                        <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Today's Academic Goal</h3>
                        <div className="rounded-xl bg-[#EAF2FF] p-4 text-[#0F3D91] border border-blue-100 flex items-start gap-3">
                          <Icons.Cpu className="h-5 w-5 text-[#2F5BEA] shrink-0 mt-0.5" />
                          <div>
                            <p className="text-xs font-extrabold">Complete active scheduling quiz</p>
                            <p className="text-[10px] text-[#0f3d91]/80 mt-1 leading-relaxed">Submit the generated practice quiz for "Operating Systems Scheduling Algorithms" to claim your daily +100 XP bonus reward.</p>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-slate-100 pt-3 flex items-center justify-between text-xs font-bold text-slate-500">
                        <span>Consistency streak: <span className="text-orange-600">{streak} Days</span></span>
                        <span className="text-[#2F5BEA]">Goal Progress: 40%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* WORKSPACE PAGE */}
              {currentPage === 'workspace' && (
                <WorkspacePage
                  topic={topic}
                  learningResource={learningResource}
                  mindMapNodes={mindMapNodes}
                  mindMapLinks={mindMapLinks}
                  flowchartSteps={flowchartSteps}
                  quizQuestions={quizQuestions}
                  isGenerating={isGenerating}
                  onTopicSearch={handleSearchTrigger}
                  xp={xp}
                  setXp={setXp}
                  streak={streak}
                  setStreak={setStreak}
                />
              )}

              {/* ACHIEVEMENTS PAGE */}
              {currentPage === 'achievements' && (
                <AchievementsPage xp={xp} streak={streak} />
              )}

              {/* PROGRESS PAGE */}
              {currentPage === 'progress' && (
                <ProgressPage />
              )}

              {/* PROFILE PAGE */}
              {currentPage === 'profile' && (
                <div className="space-y-6 p-4 md:p-6 max-w-4xl mx-auto">
                  <div className="flex flex-col gap-1">
                    <h1 className="text-2xl font-black text-[#0F3D91]">Student Profile</h1>
                    <p className="text-sm text-slate-500">Manage credentials, bookmarks, preferences, and download summaries.</p>
                  </div>

                  <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                    {/* Details Column */}
                    <div className="md:col-span-1 rounded-2xl border border-slate-200 bg-white p-5 space-y-4 shadow-xs">
                      <div className="text-center">
                        <div className="mx-auto h-20 w-20 rounded-full bg-[#EAF2FF] text-[#0F3D91] border border-slate-200 flex items-center justify-center font-bold text-2xl">
                          AM
                        </div>
                        <h3 className="text-lg font-extrabold text-[#0F3D91] mt-3">Alex Mercer</h3>
                        <p className="text-xs text-slate-400">Student ID: AM-9082</p>
                      </div>

                      <div className="border-t border-slate-100 pt-4 space-y-2.5">
                        <p className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">Academic Placement</p>
                        <div className="text-xs text-slate-600 space-y-1.5">
                          <p><span className="font-bold text-[#0F3D91]">Tier:</span> {academicProfile?.level || 'Degree'}</p>
                          {academicProfile?.degree && <p><span className="font-bold text-[#0F3D91]">Degree:</span> {academicProfile.degree}</p>}
                          {academicProfile?.branch && <p><span className="font-bold text-[#0F3D91]">Branch:</span> {academicProfile.branch}</p>}
                        </div>
                      </div>
                    </div>

                    {/* Bookmarks & saved list */}
                    <div className="md:col-span-2 space-y-4">
                      <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3.5 shadow-xs">
                        <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Bookmarked Syllabus Assets</h3>
                        <div className="space-y-2">
                          {bookmarks.map((bm) => (
                            <div key={bm} className="flex items-center justify-between p-3 rounded-xl border border-slate-100 bg-slate-50">
                              <span className="text-xs font-bold text-[#0F3D91]">{bm}</span>
                              <div className="flex gap-2">
                                <button onClick={() => handleSearchTrigger(bm)} className="text-xs text-[#2F5BEA] font-bold hover:underline cursor-pointer">
                                  Load Workspace
                                </button>
                                <button onClick={() => toggleBookmark(bm)} className="text-xs text-red-600 font-bold hover:underline cursor-pointer">
                                  Delete
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3.5 shadow-xs">
                        <h3 className="text-sm font-extrabold text-[#0F3D91] uppercase tracking-wider">Academy Settings</h3>
                        <div className="space-y-3 text-xs text-slate-600">
                          <label className="flex items-center gap-2.5 cursor-pointer">
                            <input type="checkbox" defaultChecked className="h-4 w-4 rounded border-slate-300 text-[#2F5BEA]" />
                            Enable email reminders for 7-day milestones
                          </label>
                          <label className="flex items-center gap-2.5 cursor-pointer">
                            <input type="checkbox" defaultChecked className="h-4 w-4 rounded border-slate-300 text-[#2F5BEA]" />
                            Auto-sync completed course grades to Cloud Sync
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </main>
          </div>
        </div>
      )}

      {/* MODAL 1: AUDIO MIC RECORDER SIMULATOR */}
      {showVoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-xl space-y-4">
            <h3 className="text-lg font-extrabold text-[#0F3D91]">AI Voice Chat Input</h3>
            <p className="text-xs text-slate-500">Record your question to transcribe and search automatically.</p>
            <div className="h-20 w-20 mx-auto rounded-full bg-red-50 border-4 border-red-500 flex items-center justify-center animate-pulse">
              <Icons.Mic className="h-8 w-8 text-red-500" />
            </div>
            <p className="text-xs text-slate-400">Recording speech volume...</p>
            <div className="flex gap-2 pt-2">
              <button onClick={() => setShowVoiceModal(false)} className="flex-1 rounded-xl border border-slate-200 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">
                Cancel
              </button>
              <button onClick={() => { setShowVoiceModal(false); setSearchQuery('Learn Operating Systems Scheduling Algorithms'); }} className="flex-1 rounded-xl bg-[#0F3D91] py-2 text-xs font-bold text-white shadow-md cursor-pointer">
                Transcribe & Search
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CAMERA CAPTURE SIMULATOR */}
      {showCameraModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-6 text-center shadow-xl space-y-4">
            <h3 className="text-lg font-extrabold text-[#0F3D91]">Snapshot Camera OCR Input</h3>
            <p className="text-xs text-slate-500">Align textbook questions or diagrams within the view finder.</p>
            <div className="relative overflow-hidden rounded-2xl bg-slate-950 aspect-video w-full flex items-center justify-center border border-slate-800 text-slate-600">
              <Icons.Camera className="h-10 w-10 text-slate-400" />
              <div className="absolute inset-4 border-2 border-dashed border-[#2F5BEA] rounded-xl opacity-60"></div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowCameraModal(false)} className="flex-1 rounded-xl border border-slate-200 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer">
                Close
              </button>
              <button onClick={() => { setShowCameraModal(false); setSearchQuery('Explain Bloch Sphere calculations in Quantum Physics'); }} className="flex-1 rounded-xl bg-[#0F3D91] py-2 text-xs font-bold text-white shadow-md cursor-pointer">
                Capture OCR Text
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
