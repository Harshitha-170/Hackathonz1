/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LearningPlanDay, LearningResource, MindMapNode, MindMapLink, FlowchartStep, QuizQuestion, AchievementBadge } from './types';

// Simple helper to capitalize topic words
function capitalizeWords(str: string): string {
  return str.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

export function generateCustomLearning(topicInput: string) {
  const topic = capitalizeWords(topicInput || 'Operating Systems Scheduling Algorithms');

  // Intelligent content adaptations based on keyword
  const isOS = topic.toLowerCase().includes('schedul') || topic.toLowerCase().includes('system') || topic.toLowerCase().includes('process');
  const isQuantum = topic.toLowerCase().includes('quantum') || topic.toLowerCase().includes('qubit') || topic.toLowerCase().includes('physics');
  const isPhotosynthesis = topic.toLowerCase().includes('photo') || topic.toLowerCase().includes('plant') || topic.toLowerCase().includes('bio');

  // Let's build a highly custom payload based on what the user wants to learn
  let summary = '';
  let keyConcepts: { title: string; desc: string }[] = [];
  let definitions: { term: string; meaning: string }[] = [];
  let examples: { title: string; scenario: string; steps: string[] }[] = [];
  let applications: string[] = [];
  let interviewQuestions: { q: string; a: string }[] = [];
  let realWorldUses: { title: string; desc: string }[] = [];
  let mindMapNodes: MindMapNode[] = [];
  let mindMapLinks: MindMapLink[] = [];
  let flowchartSteps: FlowchartStep[] = [];
  let quizQuestions: QuizQuestion[] = [];
  let stepsText = '';

  if (isOS) {
    summary = `Operating System scheduling algorithms are the fundamental policies used by the OS kernel to allocate CPU time slice resources among competing processes. They ensure optimal CPU utilization, prevent resource starvation, and maximize system throughput while maintaining responsive interactions.`;
    keyConcepts = [
      { title: 'CPU & I/O Burst Cycles', desc: 'Process execution consists of a cycle of CPU execution (burst) and I/O wait. Scheduling manages the active CPU burst phases.' },
      { title: 'Preemptive vs Non-Preemptive', desc: 'Preemptive schedulers can interrupt a running process mid-execution for higher priority tasks, whereas non-preemptive algorithms let processes run until completion or natural block.' },
      { title: 'Gantt Chart Visualization', desc: 'The timeline visualization tool showing start and stop boundaries of executing tasks, critical for evaluating response and turnaround metrics.' },
      { title: 'Scheduling Performance Metrics', desc: 'Throughput (tasks completed per unit time), Turnaround Time (total elapsed time), Waiting Time (idle in ready queue), and Response Time (duration until first dispatch).' }
    ];
    definitions = [
      { term: 'Process Scheduler', meaning: 'The part of the operating system that decides which ready, waiting process should be allocated the CPU next.' },
      { term: 'Ready Queue', meaning: 'A linked list or FIFO queue storing control blocks of all processes residing in main memory, ready to be dispatched.' },
      { term: 'Context Switch', meaning: 'The expensive procedure of storing the state (CPU registers, flags, stack pointer) of a running process and loading the state of the next task.' }
    ];
    examples = [
      {
        title: 'Round Robin (RR) with Time Quantum = 4ms',
        scenario: 'Three processes: P1 (Burst: 24ms), P2 (Burst: 3ms), P3 (Burst: 3ms) arrive simultaneously at Time 0.',
        steps: [
          'P1 executes for the 4ms quantum limit, leaving 20ms remaining. Preempted.',
          'P2 executes for its entire remaining burst of 3ms (terminates at T=7ms).',
          'P3 executes for its entire remaining burst of 3ms (terminates at T=10ms).',
          'P1 regains control of CPU, executing in 4ms slices until completely finished.'
        ]
      }
    ];
    applications = [
      'Cloud Server Task Distributors',
      'Real-Time Embedded Autopilot Systems',
      'High-Frequency Financial Algorithmic Platforms',
      'Desktop Multitasking GUI Dispatchers'
    ];
    interviewQuestions = [
      { q: 'What is the main drawback of Shortest Job First (SJF) scheduling?', a: 'SJF requires predicting future CPU burst durations, which is incredibly difficult in general computing. Additionally, it can cause severe starvation for long-duration processes if short processes continuously arrive.' },
      { q: 'Why is Round Robin highly sensitive to Time Quantum size?', a: 'If the quantum is extremely small, context switching overhead dominates CPU usage, degrading performance. If the quantum is extremely large, Round Robin degenerates into FCFS, degrading interactive response times.' }
    ];
    realWorldUses = [
      { title: 'Linux CFS (Completely Fair Scheduler)', desc: 'Uses a red-black tree layout to model CPU execution time, giving equal processing shares to tasks based on nice values.' },
      { title: 'Docker Container Scheduling', desc: 'Uses kernel namespaces and scheduling affinity rules to isolate process execution constraints on microservice deployments.' }
    ];
    mindMapNodes = [
      { id: 'root', label: topic, x: 250, y: 150, color: '#0F3D91', type: 'root' },
      { id: 'c1', label: 'Algorithms', x: 100, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c2', label: 'Metrics', x: 400, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c3', label: 'State Triggers', x: 100, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'c4', label: 'Context Switching', x: 400, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'd1', label: 'First Come First Served (FCFS)', x: 30, y: 30, color: '#EAF2FF', type: 'detail' },
      { id: 'd2', label: 'Shortest Job First (SJF)', x: 150, y: 20, color: '#EAF2FF', type: 'detail' },
      { id: 'd3', label: 'Round Robin (Time Slices)', x: 30, y: 110, color: '#EAF2FF', type: 'detail' },
      { id: 'd4', label: 'Turnaround Time', x: 450, y: 20, color: '#EAF2FF', type: 'detail' },
      { id: 'd5', label: 'Waiting Time & Response', x: 470, y: 100, color: '#EAF2FF', type: 'detail' },
      { id: 'd6', label: 'Ready State Queue', x: 50, y: 270, color: '#EAF2FF', type: 'detail' },
      { id: 'd7', label: 'CPU Register Storage', x: 450, y: 280, color: '#EAF2FF', type: 'detail' }
    ];
    flowchartSteps = [
      { id: 'f1', title: 'Process Admission', description: 'New process enters the active Ready Queue pool.', type: 'start' },
      { id: 'f2', title: 'Schedule Selection', description: 'Scheduler evaluates next queue member based on policies (e.g. priority or remaining burst).', type: 'process' },
      { id: 'f3', title: 'Context Switch & Launch', description: 'Save previous state, load target registers, and dispatch CPU control.', type: 'process' },
      { id: 'f4', title: 'Time Slice Expired?', description: 'Preemptive scheduler checks clock tick interrupts.', type: 'decision' },
      { id: 'f5', title: 'Ready Queue Return', description: 'Process is suspended and moved back to Ready State.', type: 'process' },
      { id: 'f6', title: 'Process Terminates', description: 'Process cleanup, resource reclamation, and output collection.', type: 'end' }
    ];
    quizQuestions = [
      {
        id: 1,
        type: 'MCQ',
        question: 'Which of the following scheduling algorithms can result in severe process starvation?',
        options: ['First-Come First-Served', 'Shortest Job First', 'Round Robin', 'Completely Fair Scheduler'],
        correctAnswer: 'Shortest Job First',
        explanation: 'In Shortest Job First, long processes can starve if a steady stream of shorter processes continuously enters the ready queue.'
      },
      {
        id: 2,
        type: 'TrueFalse',
        question: 'Preemptive scheduling allows the kernel to forcibly interrupt a currently executing process.',
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'Preemptive schedulers can interrupt a running process at any time to prioritize a newly arriving or higher-priority process.'
      },
      {
        id: 3,
        type: 'FillBlank',
        question: 'The average duration a process spends waiting in the ready queue is called _____ Time.',
        correctAnswer: 'Waiting',
        explanation: 'Waiting Time measures the total time a process spends waiting in the ready queue before execution bursts.'
      },
      {
        id: 4,
        type: 'Short',
        question: 'Explain the difference between Turnaround Time and Waiting Time.',
        correctAnswer: 'Turnaround Time includes total elapsed duration from process submission to termination. Waiting time only tracks periods idling in ready queues.',
        explanation: 'Turnaround Time = Completion Time - Arrival Time. Waiting Time = Turnaround Time - Burst Time.'
      }
    ];
  } else if (isQuantum) {
    summary = `Quantum computing utilizes fundamental quantum mechanics like superposition and entanglement to solve highly complex mathematical equations far beyond the reach of classical supercomputers. This forms the backbone of next-gen security and research.`;
    keyConcepts = [
      { title: 'Superposition States', desc: 'Unlike classical bits that are strictly 0 or 1, qubits exist in linear combinations of both states simultaneously, defined on the Bloch sphere.' },
      { title: 'Quantum Entanglement', desc: 'A physical phenomenon where multiple particles remain linked, allowing instant correlation changes across vast distances.' },
      { title: 'Quantum Decoherence', desc: 'The loss of quantum states due to environmental noise interference, requiring cryogenic cooling units.' }
    ];
    definitions = [
      { term: 'Qubit', meaning: 'The basic unit of quantum information, represented as a vector state in a 2D Hilbert space.' },
      { term: 'Bloch Sphere', meaning: 'A geometrical representation of the pure state space of a two-level quantum mechanical system.' }
    ];
    examples = [
      {
        title: 'Hadamard Gate Application',
        scenario: 'Creating a perfect superposition from a standard |0⟩ state qubit.',
        steps: [
          'Initialize a qubit in the absolute base state |0⟩.',
          'Pass the qubit through a physical Hadamard (H) gate.',
          'The state is mapped to (|0⟩ + |1⟩) / √2, with equal 50% probability of collapsing to 0 or 1 upon measurement.'
        ]
      }
    ];
    applications = [
      'Advanced Molecular Simulation',
      'Cryptographic Key Decryption (Shor\'s Algorithm)',
      'Global Supply Chain Routes Optimization',
      'Secure Quantum Communication Channels'
    ];
    interviewQuestions = [
      { q: 'How does a classical bit differ from a quantum qubit?', a: 'Classical bits are binary switches (0 or 1). Qubits represent physical wave states that utilize complex numbers to occupy superposition states, calculating multiple paths at once.' }
    ];
    realWorldUses = [
      { title: 'Superconducting Transmons', desc: 'Using Josephson junctions cooled close to absolute zero to maintain stable qubit states.' }
    ];
    mindMapNodes = [
      { id: 'root', label: topic, x: 250, y: 150, color: '#0F3D91', type: 'root' },
      { id: 'c1', label: 'Quantum States', x: 100, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c2', label: 'Qubit Tech', x: 400, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c3', label: 'Key Gates', x: 100, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'c4', label: 'Algorithms', x: 400, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'd1', label: 'Superposition Principle', x: 30, y: 30, color: '#EAF2FF', type: 'detail' },
      { id: 'd2', label: 'Entanglement Correlation', x: 150, y: 20, color: '#EAF2FF', type: 'detail' },
      { id: 'd3', label: 'Superconducting Coils', x: 450, y: 30, color: '#EAF2FF', type: 'detail' },
      { id: 'd4', label: 'Hadamard H Gate', x: 30, y: 270, color: '#EAF2FF', type: 'detail' },
      { id: 'd5', label: 'Shor\'s Prime Factoring', x: 450, y: 270, color: '#EAF2FF', type: 'detail' }
    ];
    flowchartSteps = [
      { id: 'f1', title: 'Qubit Initialization', description: 'Register clean base states |00...0⟩.', type: 'start' },
      { id: 'f2', title: 'Entanglement Application', description: 'Execute CNOT and H gates to link key qubit values.', type: 'process' },
      { id: 'f3', title: 'Algorithm Run', description: 'Manipulate probability amplitudes through target calculations.', type: 'process' },
      { id: 'f4', title: 'Decoherence Noise Check?', description: 'Assess if system environment stayed chemically stable.', type: 'decision' },
      { id: 'f5', title: 'Error Correction Loop', description: 'Re-stabilize state using physical helper qubits.', type: 'process' },
      { id: 'f6', title: 'Final Measurement', description: 'Collapse wave state to discrete classical output streams.', type: 'end' }
    ];
    quizQuestions = [
      {
        id: 1,
        type: 'MCQ',
        question: 'Which quantum gate is primarily used to put a qubit into a state of superposition?',
        options: ['Pauli-X Gate', 'Hadamard Gate', 'CNOT Gate', 'Toffoli Gate'],
        correctAnswer: 'Hadamard Gate',
        explanation: 'The Hadamard gate maps the base states |0⟩ and |1⟩ into equal superposition states.'
      },
      {
        id: 2,
        type: 'TrueFalse',
        question: 'Entangled qubits will maintain instant correlation even if separated by massive physical distances.',
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'Entanglement couples particles so measuring one instantly determines the state of the other, regardless of spatial separation.'
      }
    ];
  } else {
    // Default fallback generic topics (like Photosynthesis or any other topic typed)
    summary = `This personalized curriculum provides an in-depth academic look into ${topic}. Under modern multi-agent coordination, we explore historical contexts, core theoretical mechanisms, and practical real-world use cases to maximize retention.`;
    keyConcepts = [
      { title: 'Core Foundations', desc: `Understanding the initial mechanics, history, and structural underpinnings of ${topic}.` },
      { title: 'Primary Architecture', desc: `How structural layers, parameters, and variable factors interact dynamically within ${topic}.` },
      { title: 'Advanced Methodologies', desc: `Contemporary approaches, modern research paradigms, and complex sub-systems.` }
    ];
    definitions = [
      { term: topic, meaning: `The central field of study focusing on academic research, analytical formulations, and technical parameters.` },
      { term: 'Optimal System Interface', meaning: 'The optimized dynamic process flow maximizing educational yield and technical accuracy.' }
    ];
    examples = [
      {
        title: `Practical Demonstration of ${topic}`,
        scenario: 'A clear step-by-step example modeling core processes under default environmental constraints.',
        steps: [
          'Step 1: Set initial boundary conditions and input variables.',
          'Step 2: Initialize secondary variables and verify calibration standards.',
          'Step 3: Run processes and document quantitative output trends.'
        ]
      }
    ];
    applications = [
      'Academic Research & Peer Review',
      'Industrial Systems Design',
      'Advanced Computational Models',
      'General Technical Literacy Improvement'
    ];
    interviewQuestions = [
      { q: `What are the primary factors to evaluate when studying ${topic}?`, a: 'The fundamental variables, computational scalability, material cost models, and structural integrity constraints.' }
    ];
    realWorldUses = [
      { title: 'Educational Technology Integrations', desc: 'Deploying custom learning pipelines to optimize student comprehension rates.' }
    ];
    mindMapNodes = [
      { id: 'root', label: topic, x: 250, y: 150, color: '#0F3D91', type: 'root' },
      { id: 'c1', label: 'Foundations', x: 100, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c2', label: 'Advanced Core', x: 400, y: 70, color: '#2F5BEA', type: 'category' },
      { id: 'c3', label: 'Case Studies', x: 100, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'c4', label: 'Future Work', x: 400, y: 230, color: '#2F5BEA', type: 'category' },
      { id: 'd1', label: 'Historical Timeline', x: 30, y: 30, color: '#EAF2FF', type: 'detail' },
      { id: 'd2', label: 'Core Variables', x: 160, y: 20, color: '#EAF2FF', type: 'detail' },
      { id: 'd3', label: 'Industrial Standards', x: 450, y: 30, color: '#EAF2FF', type: 'detail' }
    ];
    flowchartSteps = [
      { id: 'f1', title: 'Conceptualization', description: `Formulate initial objectives for studying ${topic}.`, type: 'start' },
      { id: 'f2', title: 'Data Gathering', description: 'Review historical textbooks, peer papers, and analytical datasets.', type: 'process' },
      { id: 'f3', title: 'Integration Analysis', description: 'Isolate key variables and test theoretical frameworks.', type: 'process' },
      { id: 'f4', title: 'Verification Met?', description: 'Assess whether experimental outputs match established equations.', type: 'decision' },
      { id: 'f5', title: 'Model Recalibration', description: 'Re-align variables and process steps dynamically.', type: 'process' },
      { id: 'f6', title: 'Output Formulation', description: 'Synthesize findings into final professional summaries.', type: 'end' }
    ];
    quizQuestions = [
      {
        id: 1,
        type: 'MCQ',
        question: `What is the primary scientific objective of studying ${topic}?`,
        options: ['To isolate core parameters', 'To replace historical structures', 'To minimize research overhead', 'To build arbitrary workflows'],
        correctAnswer: 'To isolate core parameters',
        explanation: `Isolating key variables and core parameters is the key focus when studying ${topic}.`
      },
      {
        id: 2,
        type: 'TrueFalse',
        question: `Analyzing ${topic} requires a structured combination of theoretical and practical methodologies.`,
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'Deep educational mastery requires bridging rigorous concepts with actual examples.'
      }
    ];
  }

  // Generate 7-Day Roadmap
  const roadmap: LearningPlanDay[] = [
    { day: 1, title: `Introduction to ${topic}`, duration: '45 mins', difficulty: 'Easy', progress: 0, objectives: [`Historical Context`, `Core definitions`, `Scope of applications`] },
    { day: 2, title: `Core Theoretical Frameworks`, duration: '60 mins', difficulty: 'Medium', progress: 0, objectives: [`Primary mechanics`, `Underlying math and logic`, `Process flowcharts`] },
    { day: 3, title: `Interactive Simulations & Examples`, duration: '90 mins', difficulty: 'Hard', progress: 0, objectives: [`Step-by-step math breakdowns`, `Case study evaluations`, `Common failure modes`] },
    { day: 4, title: `Visual Analytics & Concept Maps`, duration: '50 mins', difficulty: 'Easy', progress: 0, objectives: [`Interactive Mind Maps`, `Diagram drafting`, `Visual explanations`] },
    { day: 5, title: `Exam Practice & Freeform Q&As`, duration: '75 mins', difficulty: 'Medium', progress: 0, objectives: [`Answer structures`, `Marks-based essay writing`, `Interview prompts`] },
    { day: 6, title: `Comprehensive Performance Quiz`, duration: '40 mins', difficulty: 'Medium', progress: 0, objectives: [`MCQs and true/false review`, `Real-time score assessment`, `Starvation analysis`] },
    { day: 7, title: `Capstone Assessment & Certification`, duration: '120 mins', difficulty: 'Hard', progress: 0, objectives: [`Comprehensive test`, `Weakness evaluation`, `Unlock certificate`] }
  ];

  return {
    topic,
    summary,
    keyConcepts,
    definitions,
    examples,
    applications,
    interviewQuestions,
    realWorldUses,
    mindMapNodes,
    mindMapLinks,
    flowchartSteps,
    quizQuestions,
    roadmap
  };
}

// Generate an adaptive exam answer based on the marks selected
export function generateExamAnswer(topic: string, marks: number) {
  const intro = `### INTRODUCTION (${marks >= 10 ? 'Comprehensive Context' : 'Brief Overview'})
The academic evaluation of **${topic}** forms a cornerstone in this field. ${
    marks >= 10
      ? 'This comprehensive response explores the foundational frameworks, mechanical constraints, execution cycles, and practical system models. Understanding this is vital for ensuring high-performance deployments.'
      : 'This response outlines the primary concepts and structural parameters.'
  }`;

  const explanation = `### CONCEPTUAL EXPLANATION (${marks} Marks Allocation)
At its core, **${topic}** is governed by standard system constraints and variable factors.
${
  marks >= 15
    ? `- **Primary Variables**: Under maximum load, variables scale exponentially.
- **Structural Integrity**: Concept maps must account for boundary constraints.
- **Efficiency Threshold**: Standard operational margins operate between 85% and 95%.
- **Context Preservation**: System states must preserve local parameters to avoid degradation.`
    : marks >= 5
    ? `- **Core Principles**: Standard operations govern task dispatching.
- **Variable Constraints**: Process parameters determine operational execution.`
    : `- **Basic Principle**: Tasks execute sequentially under default scheduling policies.`
}`;

  const examplesStr = `### ILLUSTRATIVE EXAMPLES
- **Real-World Case Study**: Standard implementations show high-fidelity throughput under maximum stress variables.
${
  marks >= 8
    ? `- **Procedural Execution**:
  1. Initialize target parameters at state zero.
  2. Map connection pathways dynamically.
  3. Resolve conflicts through policy rules.
  4. Measure performance response times.`
    : ''
}`;

  const diagramText = marks >= 10 ? `
\`\`\`
  [USER INPUT] ---> (ORCHESTRATOR AGENT) ---> [TASK ANALYZER]
                                                   |
                                                   v
  [LEARNING RESOURCE] <--- [MIND MAP GENERATOR] <--- [PLANNING AGENT]
\`\`\`
` : '';

  const conclusion = `### CONCLUSION
In summary, mastering **${topic}** provides students and professionals with highly optimized systemic logic. It ensures scalable deployment of analytical concepts and underpins modern research paradigms.`;

  return {
    intro,
    explanation,
    examples: examplesStr,
    diagram: diagramText,
    conclusion
  };
}

export const DEFAULT_BADGES: AchievementBadge[] = [
  { id: 'b1', title: 'Agent Commander', description: 'Orchestrated your first multi-agent collaborative learning session.', icon: 'Cpu', xpValue: 150, unlockedAt: '2026-07-16' },
  { id: 'b2', title: 'Consistency Guru', description: 'Maintained a 7-day personal learning streak.', icon: 'Flame', xpValue: 200, unlockedAt: '2026-07-15' },
  { id: 'b3', title: 'Perfect Quiz', description: 'Scored 100% on any medium-difficulty assessment quiz.', icon: 'CheckCircle', xpValue: 100 },
  { id: 'b4', title: 'Degree Master', description: 'Configured your primary academic profile setup.', icon: 'GraduationCap', xpValue: 50, unlockedAt: '2026-07-17' },
  { id: 'b5', title: 'Deep Researcher', description: 'Spent over 180 total minutes learning with agents.', icon: 'BookOpen', xpValue: 300, progress: 120, maxProgress: 180 },
  { id: 'b6', title: 'Master Explainer', description: 'Generated a comprehensive 20-mark exam answer.', icon: 'Award', xpValue: 250 }
];

export const MOCK_LEADERBOARD = [
  { rank: 1, name: 'Siddharth Roy', level: 'Post Grad', xp: 3420, active: false },
  { rank: 2, name: 'Priya Sharma', level: 'Degree (B.Tech)', xp: 2950, active: false },
  { rank: 3, name: 'Alex Mercer (You)', level: 'Degree (B.Tech)', xp: 1250, active: true },
  { rank: 4, name: 'Rohan Deshmukh', level: 'Intermediate', xp: 1100, active: false },
  { rank: 5, name: 'Ananya Rao', level: 'Class 10', xp: 850, active: false }
];
